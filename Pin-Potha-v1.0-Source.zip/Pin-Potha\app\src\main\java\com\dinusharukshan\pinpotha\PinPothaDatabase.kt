package com.dinusharukshan.pinpotha

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [GoodDeedEntity::class],
    version = 1,
    exportSchema = false
)
abstract class PinPothaDatabase : RoomDatabase() {

    abstract fun goodDeedDao(): GoodDeedDao

    companion object {

        @Volatile
        private var INSTANCE: PinPothaDatabase? = null

        fun getDatabase(context: Context): PinPothaDatabase {

            return INSTANCE ?: synchronized(this) {

                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PinPothaDatabase::class.java,
                    "pin_potha_database"
                ).build()

                INSTANCE = instance
                instance
            }
        }
    }
}