package com.dinusharukshan.pinpotha

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface GoodDeedDao {

    @Query("SELECT * FROM good_deeds ORDER BY deedDateTime DESC")
    fun getAllGoodDeeds(): Flow<List<GoodDeedEntity>>

    // Fresh one-time snapshot used by Google Drive automatic backup.
    @Query("SELECT * FROM good_deeds ORDER BY deedDateTime DESC")
    suspend fun getAllGoodDeedsOnce(): List<GoodDeedEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoodDeed(goodDeed: GoodDeedEntity)

    @Update
    suspend fun updateGoodDeed(goodDeed: GoodDeedEntity)

    @Delete
    suspend fun deleteGoodDeed(goodDeed: GoodDeedEntity)

    @Query("SELECT * FROM good_deeds WHERE id = :id LIMIT 1")
    suspend fun getGoodDeedById(id: String): GoodDeedEntity?
}
