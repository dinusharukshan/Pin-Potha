﻿# Pin Potha

**Pin Potha** is a free, open-source Android app for recording, preserving, backing up, restoring, printing, and exporting personal good deeds.

Created by **Dinusha Rukshan**.

## Features

- Record, edit and delete good deeds
- Offline-first local storage with Room
- Sinhala and English interface
- Search and date filtering
- Optional personal details
- Google Sign-In
- Google Drive hidden app-data backup
- Automatic background backup with WorkManager
- Existing backup detection
- User-friendly restore prompt
- Backup/restore status on the Home screen
- A4 PDF generation and Android printing
- Compact two-column print layout
- Light and Dark modes
- Multiple accent colors
- No ads
- No subscriptions
- No social features

## Android

- Kotlin
- Jetpack Compose
- Room
- WorkManager
- Google Credential Manager / Google Identity
- Google Drive `appDataFolder`

## Package

`com.dinusharukshan.pinpotha`

## Version

v1.0

## Google Sign-In note

Google Sign-In depends on the APK signing certificate.

The official release APK is signed by the project owner. If you clone this repository and build it with your own debug/release signing key, Google Sign-In will require an Android OAuth client configured for your own signing certificate SHA-1.

## Privacy

Good deeds are stored locally on the device. Google Sign-In and Google Drive backup are optional. Drive backup uses the app-specific hidden Google Drive app-data area.

## Release APK

The official signed APK should be downloaded from the GitHub **Releases** section rather than from the source tree.

## Author

Dinusha Rukshan
