package com.dinusharukshan.pinpotha

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "good_deeds")
data class GoodDeedEntity(

    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),

    val description: String,

    // The date and time when the good deed happened
    val deedDateTime: Long,

    // When this record was first created
    val createdAt: Long = System.currentTimeMillis(),

    // Useful later for Google Drive conflict-safe sync
    val updatedAt: Long = System.currentTimeMillis()
)