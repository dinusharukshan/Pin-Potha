package com.dinusharukshan.pinpotha

import android.content.Context
import android.app.PendingIntent
import android.content.Intent
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.Scope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.InterruptedIOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.time.Instant
import java.util.concurrent.atomic.AtomicLong


sealed class DriveAuthorizationState {

    data class Authorized(
        val accessToken: String
    ) : DriveAuthorizationState()

    data class NeedsUserConsent(
        val pendingIntent: PendingIntent
    ) : DriveAuthorizationState()

    data class Error(
        val message: String,
        val exception: Throwable? = null
    ) : DriveAuthorizationState()
}


sealed class DriveBackupResult {

    data class Success(
        val fileId: String,
        val createdNewFile: Boolean,
        val backedUpAt: Long =
            System.currentTimeMillis()
    ) : DriveBackupResult()

    data class Error(
        val message: String,
        val exception: Throwable? = null
    ) : DriveBackupResult()
}


sealed class DriveBackupCheckResult {

    data class Found(
        val fileId: String,
        val modifiedAt: Long
    ) : DriveBackupCheckResult()

    object NotFound : DriveBackupCheckResult()

    data class Error(
        val message: String,
        val exception: Throwable? = null
    ) : DriveBackupCheckResult()
}


data class DriveBackupProfile(
    val name: String,
    val phone: String,
    val address: String,
    val nic: String
)


data class DriveBackupPayload(
    val schemaVersion: Int,
    val backupCreatedAt: Long,
    val profile: DriveBackupProfile,
    val goodDeeds: List<GoodDeedEntity>
)


sealed class DriveRestoreResult {

    data class Success(
        val backup: DriveBackupPayload
    ) : DriveRestoreResult()

    data class Error(
        val message: String,
        val exception: Throwable? = null
    ) : DriveRestoreResult()
}


class GoogleDriveBackupManager(
    private val context: Context
) {

    companion object {

        const val DRIVE_APPDATA_SCOPE =
            "https://www.googleapis.com/auth/drive.appdata"

        const val BACKUP_FILE_NAME =
            "pin_potha_backup.json"

        private const val DRIVE_FILES_URL =
            "https://www.googleapis.com/drive/v3/files"

        private const val DRIVE_UPLOAD_URL =
            "https://www.googleapis.com/upload/drive/v3/files"
    }


    private val authorizationClient =
        Identity.getAuthorizationClient(context)


    // ========================================================
    // BACKUP CANCELLATION
    // ========================================================

    private val operationCounter =
        AtomicLong(0L)

    @Volatile
    private var activeOperationId: Long =
        0L

    @Volatile
    private var cancelledOperationId: Long =
        -1L

    @Volatile
    private var activeConnection: HttpURLConnection? =
        null


    /**
     * Cancels the currently running Drive HTTP operation.
     *
     * Disconnecting HttpURLConnection makes a blocked request return
     * as soon as possible. The operation id prevents the remaining
     * backup steps from continuing after cancellation.
     */
    fun cancelCurrentBackup() {

        val operationId =
            activeOperationId

        if (operationId > 0L) {
            cancelledOperationId =
                operationId
        }

        try {
            activeConnection?.disconnect()
        } catch (_: Exception) {
        }
    }


    private fun ensureNotCancelled(
        operationId: Long
    ) {

        if (
            operationId > 0L &&
            cancelledOperationId == operationId
        ) {
            throw InterruptedIOException(
                "Google Drive backup cancelled."
            )
        }
    }


    private fun registerConnection(
        operationId: Long,
        connection: HttpURLConnection
    ) {

        ensureNotCancelled(operationId)

        activeConnection =
            connection

        ensureNotCancelled(operationId)
    }


    private fun clearConnection(
        connection: HttpURLConnection
    ) {

        if (activeConnection === connection) {
            activeConnection = null
        }
    }


    // ========================================================
    // AUTHORIZATION
    // ========================================================

    private fun createAuthorizationRequest():
            AuthorizationRequest {

        val driveScope =
            Scope(DRIVE_APPDATA_SCOPE)

        return AuthorizationRequest
            .builder()
            .setRequestedScopes(
                listOf(driveScope)
            )
            .build()
    }


    fun requestDriveAuthorization(
        onResult: (DriveAuthorizationState) -> Unit
    ) {

        val request =
            createAuthorizationRequest()

        authorizationClient
            .authorize(request)
            .addOnSuccessListener { result ->

                handleAuthorizationResult(
                    authorizationResult = result,
                    onResult = onResult
                )
            }
            .addOnFailureListener { exception ->

                onResult(
                    DriveAuthorizationState.Error(
                        message =
                            exception.localizedMessage
                                ?: "Google Drive authorization failed.",
                        exception =
                            exception
                    )
                )
            }
    }


    fun handleAuthorizationIntent(
        data: Intent?,
        onResult: (DriveAuthorizationState) -> Unit
    ) {

        if (data == null) {

            onResult(
                DriveAuthorizationState.Error(
                    message =
                        "Google Drive authorization was cancelled."
                )
            )

            return
        }

        try {

            val result =
                authorizationClient
                    .getAuthorizationResultFromIntent(
                        data
                    )

            handleAuthorizationResult(
                authorizationResult = result,
                onResult = onResult
            )

        } catch (exception: ApiException) {

            onResult(
                DriveAuthorizationState.Error(
                    message =
                        exception.localizedMessage
                            ?: "Google Drive authorization failed.",
                    exception =
                        exception
                )
            )

        } catch (exception: Exception) {

            onResult(
                DriveAuthorizationState.Error(
                    message =
                        exception.localizedMessage
                            ?: "Unexpected Google Drive authorization error.",
                    exception =
                        exception
                )
            )
        }
    }


    private fun handleAuthorizationResult(
        authorizationResult: AuthorizationResult,
        onResult: (DriveAuthorizationState) -> Unit
    ) {

        if (authorizationResult.hasResolution()) {

            val pendingIntent =
                authorizationResult.pendingIntent

            if (pendingIntent != null) {

                onResult(
                    DriveAuthorizationState
                        .NeedsUserConsent(
                            pendingIntent
                        )
                )

            } else {

                onResult(
                    DriveAuthorizationState.Error(
                        message =
                            "Google Drive permission screen could not be opened."
                    )
                )
            }

            return
        }

        val accessToken =
            authorizationResult.accessToken

        if (!accessToken.isNullOrBlank()) {

            onResult(
                DriveAuthorizationState.Authorized(
                    accessToken = accessToken
                )
            )

        } else {

            onResult(
                DriveAuthorizationState.Error(
                    message =
                        "Google Drive authorization succeeded, but no access token was returned."
                )
            )
        }
    }


    // ========================================================
    // CREATE BACKUP JSON
    // ========================================================

    fun createBackupJson(
        profileName: String,
        profilePhone: String,
        profileAddress: String,
        profileNic: String,
        goodDeeds: List<GoodDeedEntity>
    ): String {

        val root =
            JSONObject()

        root.put(
            "schemaVersion",
            1
        )

        root.put(
            "backupCreatedAt",
            System.currentTimeMillis()
        )

        val profile =
            JSONObject()

        profile.put(
            "name",
            profileName
        )

        profile.put(
            "phone",
            profilePhone
        )

        profile.put(
            "address",
            profileAddress
        )

        profile.put(
            "nic",
            profileNic
        )

        root.put(
            "profile",
            profile
        )

        val deedsArray =
            JSONArray()

        goodDeeds.forEach { deed ->

            val deedJson =
                JSONObject()

            deedJson.put(
                "id",
                deed.id
            )

            deedJson.put(
                "description",
                deed.description
            )

            deedJson.put(
                "deedDateTime",
                deed.deedDateTime
            )

            deedJson.put(
                "createdAt",
                deed.createdAt
            )

            deedJson.put(
                "updatedAt",
                deed.updatedAt
            )

            deedsArray.put(
                deedJson
            )
        }

        root.put(
            "goodDeeds",
            deedsArray
        )

        return root.toString(2)
    }


    // ========================================================
    // CHECK FOR AN EXISTING BACKUP
    // ========================================================

    suspend fun checkForExistingBackup(
        accessToken: String
    ): DriveBackupCheckResult {

        return withContext(Dispatchers.IO) {

            try {

                val escapedFileName =
                    BACKUP_FILE_NAME
                        .replace(
                            "\\",
                            "\\\\"
                        )
                        .replace(
                            "'",
                            "\\'"
                        )

                val query =
                    "'appDataFolder' in parents " +
                            "and name = '$escapedFileName' " +
                            "and trashed = false"

                val encodedQuery =
                    URLEncoder.encode(
                        query,
                        "UTF-8"
                    )

                val requestUrl =
                    "$DRIVE_FILES_URL" +
                            "?spaces=appDataFolder" +
                            "&q=$encodedQuery" +
                            "&fields=files(id,name,modifiedTime)" +
                            "&orderBy=modifiedTime desc" +
                            "&pageSize=1"

                val connection =
                    URL(requestUrl)
                        .openConnection()
                            as HttpURLConnection

                try {

                    connection.requestMethod =
                        "GET"

                    connection.setRequestProperty(
                        "Authorization",
                        "Bearer $accessToken"
                    )

                    connection.setRequestProperty(
                        "Accept",
                        "application/json"
                    )

                    connection.connectTimeout =
                        15000

                    connection.readTimeout =
                        15000

                    val responseCode =
                        connection.responseCode

                    val responseText =
                        readResponseText(
                            connection
                        )

                    if (responseCode !in 200..299) {

                        throw Exception(
                            "Drive backup check failed ($responseCode): $responseText"
                        )
                    }

                    val root =
                        JSONObject(responseText)

                    val files =
                        root.optJSONArray("files")
                            ?: JSONArray()

                    if (files.length() == 0) {

                        DriveBackupCheckResult.NotFound

                    } else {

                        val file =
                            files.getJSONObject(0)

                        val fileId =
                            file.getString("id")

                        val modifiedTime =
                            file.optString(
                                "modifiedTime",
                                ""
                            )

                        val modifiedAt =
                            runCatching {
                                Instant
                                    .parse(modifiedTime)
                                    .toEpochMilli()
                            }.getOrDefault(0L)

                        DriveBackupCheckResult.Found(
                            fileId = fileId,
                            modifiedAt = modifiedAt
                        )
                    }

                } finally {

                    connection.disconnect()
                }

            } catch (exception: Exception) {

                DriveBackupCheckResult.Error(
                    message =
                        exception.localizedMessage
                            ?: "Could not check Google Drive for an existing backup.",
                    exception =
                        exception
                )
            }
        }
    }


    // ========================================================
    // DOWNLOAD + PARSE BACKUP FOR RESTORE
    // ========================================================

    suspend fun downloadBackupFromDrive(
        accessToken: String,
        fileId: String
    ): DriveRestoreResult {

        return withContext(Dispatchers.IO) {

            try {

                val requestUrl =
                    "$DRIVE_FILES_URL/$fileId?alt=media"

                val connection =
                    URL(requestUrl)
                        .openConnection()
                            as HttpURLConnection

                try {

                    connection.requestMethod =
                        "GET"

                    connection.setRequestProperty(
                        "Authorization",
                        "Bearer $accessToken"
                    )

                    connection.setRequestProperty(
                        "Accept",
                        "application/json"
                    )

                    connection.connectTimeout =
                        20000

                    connection.readTimeout =
                        20000

                    val responseCode =
                        connection.responseCode

                    val responseText =
                        readResponseText(connection)

                    if (responseCode !in 200..299) {
                        throw Exception(
                            "Drive restore download failed ($responseCode): $responseText"
                        )
                    }

                    val root =
                        JSONObject(responseText)

                    val schemaVersion =
                        root.optInt("schemaVersion", 1)

                    if (schemaVersion != 1) {
                        throw Exception(
                            "Unsupported Pin Potha backup version: $schemaVersion"
                        )
                    }

                    val backupCreatedAt =
                        root.optLong("backupCreatedAt", 0L)

                    val profileJson =
                        root.optJSONObject("profile")
                            ?: JSONObject()

                    val profile =
                        DriveBackupProfile(
                            name = profileJson.optString("name", ""),
                            phone = profileJson.optString("phone", ""),
                            address = profileJson.optString("address", ""),
                            nic = profileJson.optString("nic", "")
                        )

                    val deedsJson =
                        root.optJSONArray("goodDeeds")
                            ?: JSONArray()

                    val deeds =
                        mutableListOf<GoodDeedEntity>()

                    for (index in 0 until deedsJson.length()) {

                        val deedJson =
                            deedsJson.optJSONObject(index)
                                ?: continue

                        val id =
                            deedJson.optString("id", "")

                        val description =
                            deedJson.optString("description", "")

                        val deedDateTime =
                            deedJson.optLong("deedDateTime", 0L)

                        if (
                            id.isBlank() ||
                            description.isBlank() ||
                            deedDateTime <= 0L
                        ) {
                            continue
                        }

                        val createdAt =
                            deedJson.optLong(
                                "createdAt",
                                deedDateTime
                            )

                        val updatedAt =
                            deedJson.optLong(
                                "updatedAt",
                                createdAt
                            )

                        deeds.add(
                            GoodDeedEntity(
                                id = id,
                                description = description,
                                deedDateTime = deedDateTime,
                                createdAt = createdAt,
                                updatedAt = updatedAt
                            )
                        )
                    }

                    DriveRestoreResult.Success(
                        backup = DriveBackupPayload(
                            schemaVersion = schemaVersion,
                            backupCreatedAt = backupCreatedAt,
                            profile = profile,
                            goodDeeds = deeds
                        )
                    )

                } finally {
                    connection.disconnect()
                }

            } catch (exception: Exception) {

                DriveRestoreResult.Error(
                    message =
                        exception.localizedMessage
                            ?: "Google Drive restore failed.",
                    exception = exception
                )
            }
        }
    }


    // ========================================================
    // BACKUP TO DRIVE
    // ========================================================

    suspend fun backupJsonToDrive(
        accessToken: String,
        backupJson: String
    ): DriveBackupResult {

        return withContext(Dispatchers.IO) {

            val operationId =
                operationCounter.incrementAndGet()

            activeOperationId =
                operationId

            try {

                ensureNotCancelled(
                    operationId
                )

                val existingFileId =
                    findExistingBackupFile(
                        accessToken = accessToken,
                        operationId = operationId
                    )

                ensureNotCancelled(
                    operationId
                )

                if (existingFileId == null) {

                    val newFileId =
                        createBackupFile(
                            accessToken = accessToken,
                            backupJson = backupJson,
                            operationId = operationId
                        )

                    ensureNotCancelled(
                        operationId
                    )

                    DriveBackupResult.Success(
                        fileId = newFileId,
                        createdNewFile = true
                    )

                } else {

                    updateBackupFile(
                        accessToken = accessToken,
                        fileId = existingFileId,
                        backupJson = backupJson,
                        operationId = operationId
                    )

                    ensureNotCancelled(
                        operationId
                    )

                    DriveBackupResult.Success(
                        fileId = existingFileId,
                        createdNewFile = false
                    )
                }

            } catch (exception: Exception) {

                DriveBackupResult.Error(
                    message =
                        exception.localizedMessage
                            ?: "Google Drive backup failed.",
                    exception =
                        exception
                )

            } finally {

                if (activeOperationId == operationId) {
                    activeOperationId = 0L
                }

                activeConnection = null
            }
        }
    }


    // ========================================================
    // FIND EXISTING BACKUP
    // ========================================================

    private fun findExistingBackupFile(
        accessToken: String,
        operationId: Long
    ): String? {

        ensureNotCancelled(
            operationId
        )

        val escapedFileName =
            BACKUP_FILE_NAME
                .replace(
                    "\\",
                    "\\\\"
                )
                .replace(
                    "'",
                    "\\'"
                )

        val query =
            "'appDataFolder' in parents " +
                    "and name = '$escapedFileName' " +
                    "and trashed = false"

        val encodedQuery =
            URLEncoder.encode(
                query,
                "UTF-8"
            )

        val requestUrl =
            "$DRIVE_FILES_URL" +
                    "?spaces=appDataFolder" +
                    "&q=$encodedQuery" +
                    "&fields=files(id,name,modifiedTime)" +
                    "&pageSize=10"

        val connection =
            URL(requestUrl)
                .openConnection()
                    as HttpURLConnection

        registerConnection(
            operationId = operationId,
            connection = connection
        )

        try {

            connection.requestMethod =
                "GET"

            connection.setRequestProperty(
                "Authorization",
                "Bearer $accessToken"
            )

            connection.setRequestProperty(
                "Accept",
                "application/json"
            )

            connection.connectTimeout =
                15000

            connection.readTimeout =
                15000

            ensureNotCancelled(
                operationId
            )

            val responseCode =
                connection.responseCode

            ensureNotCancelled(
                operationId
            )

            val responseText =
                readResponseText(
                    connection
                )

            ensureNotCancelled(
                operationId
            )

            if (responseCode !in 200..299) {

                throw Exception(
                    "Drive search failed ($responseCode): $responseText"
                )
            }

            val root =
                JSONObject(responseText)

            val files =
                root.optJSONArray("files")
                    ?: JSONArray()

            if (files.length() == 0) {
                return null
            }

            return files
                .getJSONObject(0)
                .getString("id")

        } finally {

            clearConnection(
                connection
            )

            connection.disconnect()
        }
    }


    // ========================================================
    // CREATE BACKUP FILE
    // ========================================================

    private fun createBackupFile(
        accessToken: String,
        backupJson: String,
        operationId: Long
    ): String {

        ensureNotCancelled(
            operationId
        )

        val boundary =
            "pin_potha_boundary_" +
                    System.currentTimeMillis()

        val metadata =
            JSONObject()
                .put(
                    "name",
                    BACKUP_FILE_NAME
                )
                .put(
                    "mimeType",
                    "application/json"
                )
                .put(
                    "parents",
                    JSONArray()
                        .put("appDataFolder")
                )
                .toString()

        val body =
            buildString {
                append(
                    "--$boundary\r\n"
                )

                append(
                    "Content-Type: application/json; charset=UTF-8\r\n"
                )

                append("\r\n")
                append(metadata)
                append("\r\n")

                append(
                    "--$boundary\r\n"
                )

                append(
                    "Content-Type: application/json; charset=UTF-8\r\n"
                )

                append("\r\n")
                append(backupJson)
                append("\r\n")

                append(
                    "--$boundary--\r\n"
                )
            }

        val requestUrl =
            "$DRIVE_UPLOAD_URL" +
                    "?uploadType=multipart" +
                    "&fields=id,name,modifiedTime"

        val connection =
            URL(requestUrl)
                .openConnection()
                    as HttpURLConnection

        registerConnection(
            operationId = operationId,
            connection = connection
        )

        try {

            connection.requestMethod =
                "POST"

            connection.doOutput =
                true

            connection.setRequestProperty(
                "Authorization",
                "Bearer $accessToken"
            )

            connection.setRequestProperty(
                "Content-Type",
                "multipart/related; boundary=$boundary"
            )

            connection.setRequestProperty(
                "Accept",
                "application/json"
            )

            connection.connectTimeout =
                20000

            connection.readTimeout =
                20000

            val bodyBytes =
                body.toByteArray(
                    StandardCharsets.UTF_8
                )

            connection.setFixedLengthStreamingMode(
                bodyBytes.size
            )

            ensureNotCancelled(
                operationId
            )

            connection.outputStream.use { output ->
                output.write(bodyBytes)
            }

            ensureNotCancelled(
                operationId
            )

            val responseCode =
                connection.responseCode

            ensureNotCancelled(
                operationId
            )

            val responseText =
                readResponseText(
                    connection
                )

            ensureNotCancelled(
                operationId
            )

            if (responseCode !in 200..299) {

                throw Exception(
                    "Drive file creation failed ($responseCode): $responseText"
                )
            }

            val responseJson =
                JSONObject(responseText)

            return responseJson
                .getString("id")

        } finally {

            clearConnection(
                connection
            )

            connection.disconnect()
        }
    }


    // ========================================================
    // UPDATE EXISTING BACKUP FILE
    // ========================================================

    private fun updateBackupFile(
        accessToken: String,
        fileId: String,
        backupJson: String,
        operationId: Long
    ) {

        ensureNotCancelled(
            operationId
        )

        val requestUrl =
            "$DRIVE_UPLOAD_URL/" +
                    fileId +
                    "?uploadType=media" +
                    "&fields=id,name,modifiedTime"

        val connection =
            URL(requestUrl)
                .openConnection()
                    as HttpURLConnection

        registerConnection(
            operationId = operationId,
            connection = connection
        )

        try {

            connection.requestMethod =
                "POST"

            connection.setRequestProperty(
                "X-HTTP-Method-Override",
                "PATCH"
            )

            connection.doOutput =
                true

            connection.setRequestProperty(
                "Authorization",
                "Bearer $accessToken"
            )

            connection.setRequestProperty(
                "Content-Type",
                "application/json; charset=UTF-8"
            )

            connection.setRequestProperty(
                "Accept",
                "application/json"
            )

            connection.connectTimeout =
                20000

            connection.readTimeout =
                20000

            val data =
                backupJson.toByteArray(
                    StandardCharsets.UTF_8
                )

            connection.setFixedLengthStreamingMode(
                data.size
            )

            ensureNotCancelled(
                operationId
            )

            connection.outputStream.use { output ->
                output.write(data)
            }

            ensureNotCancelled(
                operationId
            )

            val responseCode =
                connection.responseCode

            ensureNotCancelled(
                operationId
            )

            val responseText =
                readResponseText(
                    connection
                )

            ensureNotCancelled(
                operationId
            )

            if (responseCode !in 200..299) {

                throw Exception(
                    "Drive backup update failed ($responseCode): $responseText"
                )
            }

        } finally {

            clearConnection(
                connection
            )

            connection.disconnect()
        }
    }


    // ========================================================
    // HTTP RESPONSE
    // ========================================================

    private fun readResponseText(
        connection: HttpURLConnection
    ): String {

        val stream =
            if (
                connection.responseCode in 200..299
            ) {
                connection.inputStream
            } else {
                connection.errorStream
            }

        if (stream == null) {
            return ""
        }

        return stream
            .bufferedReader(
                StandardCharsets.UTF_8
            )
            .use {
                it.readText()
            }
    }
}
