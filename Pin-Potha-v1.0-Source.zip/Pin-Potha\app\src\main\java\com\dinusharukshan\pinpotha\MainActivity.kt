package com.dinusharukshan.pinpotha

import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialException
import com.dinusharukshan.pinpotha.ui.theme.PinPothaAccent
import com.dinusharukshan.pinpotha.ui.theme.PinPothaTheme
import com.dinusharukshan.pinpotha.ui.theme.accentPreviewColor
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter

const val WEB_CLIENT_ID =
    "784590561601-ekmoqme58dfoh4u35k86t4poojh5tvvr.apps.googleusercontent.com"

enum class AppLanguage { SINHALA, ENGLISH }

enum class AppThemeMode { LIGHT, DARK }

enum class AppScreen {
    LANGUAGE,
    GOOGLE,
    HOME,
    ADD,
    EDIT,
    SETTINGS,
    PERSONAL_DETAILS,
    PRINT_EXPORT
}

enum class DateFilter { ALL, THIS_MONTH, THIS_YEAR, CUSTOM }

fun tr(language: AppLanguage, sinhala: String, english: String): String =
    if (language == AppLanguage.SINHALA) sinhala else english

fun formatBackupDateTime(timestamp: Long): String {
    if (timestamp <= 0L) return ""
    return Instant.ofEpochMilli(timestamp)
        .atZone(ZoneId.systemDefault())
        .format(DateTimeFormatter.ofPattern("dd MMM yyyy • hh:mm a"))
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val preferences = remember {
                this@MainActivity.getSharedPreferences(
                    "pin_potha_preferences",
                    Context.MODE_PRIVATE
                )
            }

            val savedThemeMode = remember {
                preferences.getString(
                    "app_theme_mode",
                    AppThemeMode.LIGHT.name
                )?.let { saved ->
                    runCatching {
                        AppThemeMode.valueOf(saved)
                    }.getOrNull()
                } ?: AppThemeMode.LIGHT
            }

            var appThemeMode by remember {
                mutableStateOf(savedThemeMode)
            }

            val savedAccentColor = remember {
                preferences.getString(
                    "app_accent_color",
                    PinPothaAccent.PURPLE.name
                )?.let { saved ->
                    runCatching {
                        PinPothaAccent.valueOf(saved)
                    }.getOrNull()
                } ?: PinPothaAccent.PURPLE
            }

            var appAccentColor by remember {
                mutableStateOf(savedAccentColor)
            }

            val useDarkTheme =
                appThemeMode == AppThemeMode.DARK

            DisposableEffect(useDarkTheme) {
                val controller =
                    WindowCompat.getInsetsController(
                        window,
                        window.decorView
                    )

                controller.isAppearanceLightStatusBars =
                    !useDarkTheme

                controller.isAppearanceLightNavigationBars =
                    !useDarkTheme

                onDispose { }
            }

            PinPothaTheme(
                darkTheme = useDarkTheme,
                accent = appAccentColor
            ) {
                val context = LocalContext.current

                val credentialManager = remember {
                    CredentialManager.create(this@MainActivity)
                }

                val driveBackupManager = remember {
                    GoogleDriveBackupManager(this@MainActivity)
                }

                val pdfManager = remember {
                    PinPothaPdfManager(this@MainActivity)
                }

                val coroutineScope = rememberCoroutineScope()

                val savedLanguage = remember {
                    preferences.getString("app_language", null)?.let { saved ->
                        runCatching { AppLanguage.valueOf(saved) }.getOrNull()
                    }
                }

                var appLanguage by remember { mutableStateOf(savedLanguage) }

                var googleSignedIn by remember {
                    mutableStateOf(
                        preferences.getBoolean("google_signed_in", false)
                    )
                }

                var googleEmail by remember {
                    mutableStateOf(
                        preferences.getString("google_email", "") ?: ""
                    )
                }

                var googleName by remember {
                    mutableStateOf(
                        preferences.getString("google_name", "") ?: ""
                    )
                }

                var googleUniqueId by remember {
                    mutableStateOf(
                        preferences.getString("google_unique_id", "") ?: ""
                    )
                }

                var googleSignInLoading by remember { mutableStateOf(false) }
                var googleSignInError by remember { mutableStateOf<String?>(null) }

                var driveAccessGranted by remember {
                    mutableStateOf(
                        preferences.getBoolean("drive_access_granted", false)
                    )
                }

                var driveAuthorizationLoading by remember { mutableStateOf(false) }
                var driveAuthorizationError by remember { mutableStateOf<String?>(null) }

                var backupInProgress by remember { mutableStateOf(false) }
                var backupMessage by remember { mutableStateOf<String?>(null) }
                var backupError by remember { mutableStateOf<String?>(null) }

                var lastBackupAt by remember {
                    mutableStateOf(
                        preferences.getLong("last_backup_at", 0L)
                    )
                }

                var pdfExportInProgress by remember {
                    mutableStateOf(false)
                }

                var pdfMessage by remember {
                    mutableStateOf<String?>(null)
                }

                var pdfError by remember {
                    mutableStateOf<String?>(null)
                }

                var pendingPdfForSave by remember {
                    mutableStateOf<java.io.File?>(null)
                }

                var autoBackupPending by remember {
                    mutableStateOf(
                        AutoBackupScheduler.isBackupPending(preferences)
                    )
                }

                var autoBackupError by remember {
                    mutableStateOf(
                        preferences.getString(
                            AutoBackupScheduler.PREF_AUTO_BACKUP_ERROR,
                            null
                        )
                    )
                }

                DisposableEffect(preferences) {
                    val listener =
                        SharedPreferences.OnSharedPreferenceChangeListener { prefs, key ->
                            when (key) {
                                "last_backup_at" -> {
                                    lastBackupAt =
                                        prefs.getLong("last_backup_at", 0L)
                                }

                                AutoBackupScheduler.PREF_CHANGE_VERSION,
                                AutoBackupScheduler.PREF_LAST_BACKED_UP_VERSION -> {
                                    autoBackupPending =
                                        AutoBackupScheduler.isBackupPending(prefs)
                                }

                                AutoBackupScheduler.PREF_AUTO_BACKUP_ERROR -> {
                                    autoBackupError =
                                        prefs.getString(
                                            AutoBackupScheduler.PREF_AUTO_BACKUP_ERROR,
                                            null
                                        )
                                }
                            }
                        }

                    preferences.registerOnSharedPreferenceChangeListener(
                        listener
                    )

                    onDispose {
                        preferences.unregisterOnSharedPreferenceChangeListener(
                            listener
                        )
                    }
                }

                var pendingBackupAfterConsent by remember { mutableStateOf(false) }
                var pendingBackupCheckAfterConsent by remember { mutableStateOf(false) }
                var requestCloudCheckAfterSignIn by remember { mutableStateOf(googleSignedIn) }

                var cloudBackupCheckInProgress by remember { mutableStateOf(false) }
                var cloudBackupFound by remember { mutableStateOf(false) }
                var cloudBackupFileId by remember { mutableStateOf<String?>(null) }
                var cloudBackupModifiedAt by remember { mutableStateOf(0L) }

                var restoreInProgress by remember { mutableStateOf(false) }
                var restoreMessage by remember { mutableStateOf<String?>(null) }
                var restoreError by remember { mutableStateOf<String?>(null) }
                var pendingRestoreAfterConsent by remember { mutableStateOf(false) }


                var profileName by remember {
                    mutableStateOf(
                        preferences.getString("profile_name", "") ?: ""
                    )
                }

                var profilePhone by remember {
                    mutableStateOf(
                        preferences.getString("profile_phone", "") ?: ""
                    )
                }

                var profileAddress by remember {
                    mutableStateOf(
                        preferences.getString("profile_address", "") ?: ""
                    )
                }

                var profileNic by remember {
                    mutableStateOf(
                        preferences.getString("profile_nic", "") ?: ""
                    )
                }

                val database = remember {
                    PinPothaDatabase.getDatabase(context)
                }

                val dao = remember { database.goodDeedDao() }

                val goodDeeds by dao.getAllGoodDeeds().collectAsState(
                    initial = emptyList()
                )

                var currentScreen by remember {
                    mutableStateOf(
                        when {
                            savedLanguage == null -> AppScreen.LANGUAGE
                            googleSignedIn -> AppScreen.HOME
                            else -> AppScreen.GOOGLE
                        }
                    )
                }

                var selectedGoodDeed by remember {
                    mutableStateOf<GoodDeedEntity?>(null)
                }

                var googleReturnScreen by remember {
                    mutableStateOf<AppScreen?>(null)
                }

                val language = appLanguage ?: AppLanguage.ENGLISH

                var showStartupSplash by remember {
                    mutableStateOf(true)
                }

                LaunchedEffect(Unit) {
                    delay(650)
                    showStartupSplash = false
                }

                val savePdfLauncher =
                    rememberLauncherForActivityResult(
                        contract =
                            ActivityResultContracts.CreateDocument(
                                "application/pdf"
                            )
                    ) { uri ->
                        val sourceFile = pendingPdfForSave
                        pendingPdfForSave = null

                        if (uri != null && sourceFile != null) {
                            pdfExportInProgress = true
                            pdfMessage = null
                            pdfError = null

                            coroutineScope.launch {
                                try {
                                    withContext(Dispatchers.IO) {
                                        pdfManager.savePdfToUri(
                                            sourceFile = sourceFile,
                                            destinationUri = uri
                                        )
                                    }

                                    pdfMessage =
                                        tr(
                                            language,
                                            "PDF ගොනුව සාර්ථකව සුරකින ලදී.",
                                            "PDF saved successfully."
                                        )
                                } catch (exception: Exception) {
                                    pdfError =
                                        exception.localizedMessage
                                            ?: tr(
                                                language,
                                                "PDF ගොනුව සුරැකීමට නොහැකි විය.",
                                                "Could not save the PDF."
                                            )
                                } finally {
                                    pdfExportInProgress = false
                                }
                            }
                        }
                    }

                fun markDriveAuthorized() {
                    driveAccessGranted = true
                    driveAuthorizationError = null
                    preferences.edit()
                        .putBoolean("drive_access_granted", true)
                        .apply()
                }

                fun performBackupWithToken(accessToken: String) {
                    if (backupInProgress) return

                    AutoBackupScheduler.cancelScheduledWork(
                        context
                    )

                    backupInProgress = true
                    backupMessage = null
                    backupError = null

                    val backupJson = driveBackupManager.createBackupJson(
                        profileName = profileName,
                        profilePhone = profilePhone,
                        profileAddress = profileAddress,
                        profileNic = profileNic,
                        goodDeeds = goodDeeds
                    )

                    coroutineScope.launch {
                        when (
                            val result = driveBackupManager.backupJsonToDrive(
                                accessToken = accessToken,
                                backupJson = backupJson
                            )
                        ) {
                            is DriveBackupResult.Success -> {
                                backupInProgress = false
                                cloudBackupFound = true
                                cloudBackupFileId = result.fileId
                                cloudBackupModifiedAt = result.backedUpAt
                                lastBackupAt = result.backedUpAt
                                preferences.edit()
                                    .putLong("last_backup_at", result.backedUpAt)
                                    .apply()

                                AutoBackupScheduler.markBackupCompleted(
                                    context = context,
                                    backedUpAt = result.backedUpAt
                                )

                                backupMessage = tr(
                                    language,
                                    "Google Drive උපස්ථය සාර්ථකයි.",
                                    "Google Drive backup completed successfully."
                                )
                            }

                            is DriveBackupResult.Error -> {
                                backupInProgress = false
                                backupError = result.message

                                AutoBackupScheduler.scheduleIfNeeded(
                                    context
                                )
                            }
                        }
                    }
                }

                fun performBackupCheckWithToken(accessToken: String) {
                    if (cloudBackupCheckInProgress) return

                    cloudBackupCheckInProgress = true
                    driveAuthorizationError = null

                    coroutineScope.launch {
                        when (
                            val result = driveBackupManager.checkForExistingBackup(
                                accessToken = accessToken
                            )
                        ) {
                            is DriveBackupCheckResult.Found -> {
                                cloudBackupCheckInProgress = false
                                cloudBackupFound = true
                                cloudBackupFileId = result.fileId
                                cloudBackupModifiedAt = result.modifiedAt

                                if (result.modifiedAt > 0L) {
                                    lastBackupAt = result.modifiedAt
                                    preferences.edit()
                                        .putLong(
                                            "last_backup_at",
                                            result.modifiedAt
                                        )
                                        .apply()
                                }

                                backupError = null

                                // Detection only. The Home screen will show a
                                // small "backup available" status and, on a
                                // fresh/empty local database, ask the user
                                // whether they want to restore.
                                backupMessage = tr(
                                    language,
                                    "Google Drive හි පෙර උපස්ථයක් හමු විය.",
                                    "Existing Google Drive backup found."
                                )

                                AutoBackupScheduler.scheduleIfNeeded(
                                    context
                                )
                            }

                            DriveBackupCheckResult.NotFound -> {
                                cloudBackupCheckInProgress = false
                                cloudBackupFound = false
                                cloudBackupFileId = null
                                cloudBackupModifiedAt = 0L
                                lastBackupAt = 0L
                                preferences.edit()
                                    .remove("last_backup_at")
                                    .apply()

                                backupMessage = tr(
                                    language,
                                    "Google Drive හි පෙර උපස්ථයක් හමු නොවීය.",
                                    "No previous Google Drive backup was found."
                                )
                                backupError = null

                                AutoBackupScheduler.scheduleIfNeeded(
                                    context
                                )
                            }

                            is DriveBackupCheckResult.Error -> {
                                cloudBackupCheckInProgress = false
                                backupError = result.message
                            }
                        }
                    }
                }

                fun performRestoreWithToken(accessToken: String) {

                    if (restoreInProgress) return

                    val fileId = cloudBackupFileId

                    if (fileId.isNullOrBlank()) {
                        restoreError = tr(
                            language,
                            "ප්‍රතිසාධනය කිරීමට Google Drive උපස්ථයක් හමු නොවීය.",
                            "No Google Drive backup is available to restore."
                        )
                        return
                    }

                    AutoBackupScheduler.cancelScheduledWork(
                        context
                    )

                    restoreInProgress = true
                    restoreMessage = null
                    restoreError = null
                    backupMessage = null
                    backupError = null

                    coroutineScope.launch {
                        when (
                            val result =
                                driveBackupManager.downloadBackupFromDrive(
                                    accessToken = accessToken,
                                    fileId = fileId
                                )
                        ) {
                            is DriveRestoreResult.Success -> {
                                try {
                                    val backup = result.backup
                                    val localDeeds =
                                        dao.getAllGoodDeedsOnce()
                                    val localById =
                                        localDeeds.associateBy { it.id }

                                    var restoredCount = 0
                                    var updatedCount = 0

                                    backup.goodDeeds.forEach { remoteDeed ->
                                        val localDeed =
                                            localById[remoteDeed.id]

                                        when {
                                            localDeed == null -> {
                                                dao.insertGoodDeed(remoteDeed)
                                                restoredCount++
                                            }

                                            remoteDeed.updatedAt >
                                                    localDeed.updatedAt -> {
                                                dao.insertGoodDeed(remoteDeed)
                                                updatedCount++
                                            }
                                        }
                                    }

                                    val mergedName =
                                        if (profileName.isBlank()) {
                                            backup.profile.name.trim()
                                        } else {
                                            profileName
                                        }

                                    val mergedPhone =
                                        if (profilePhone.isBlank()) {
                                            backup.profile.phone.trim()
                                        } else {
                                            profilePhone
                                        }

                                    val mergedAddress =
                                        if (profileAddress.isBlank()) {
                                            backup.profile.address.trim()
                                        } else {
                                            profileAddress
                                        }

                                    val mergedNic =
                                        if (profileNic.isBlank()) {
                                            backup.profile.nic.trim()
                                        } else {
                                            profileNic
                                        }

                                    profileName = mergedName
                                    profilePhone = mergedPhone
                                    profileAddress = mergedAddress
                                    profileNic = mergedNic

                                    preferences.edit()
                                        .putString("profile_name", mergedName)
                                        .putString("profile_phone", mergedPhone)
                                        .putString("profile_address", mergedAddress)
                                        .putString("profile_nic", mergedNic)
                                        .apply()

                                    val restoredBackupTime =
                                        when {
                                            cloudBackupModifiedAt > 0L ->
                                                cloudBackupModifiedAt
                                            backup.backupCreatedAt > 0L ->
                                                backup.backupCreatedAt
                                            else ->
                                                System.currentTimeMillis()
                                        }

                                    lastBackupAt = restoredBackupTime
                                    preferences.edit()
                                        .putLong(
                                            "last_backup_at",
                                            restoredBackupTime
                                        )
                                        .apply()

                                    restoreInProgress = false
                                    restoreMessage = tr(
                                        language,
                                        "ප්‍රතිසාධනය සාර්ථකයි. නව පින්කම් $restoredCount ක් සහ යාවත්කාලීන කළ පින්කම් $updatedCount ක් ඒකාබද්ධ කරන ලදී.",
                                        "Restore completed. $restoredCount new good deeds and $updatedCount newer good deeds were merged."
                                    )

                                    AutoBackupScheduler.scheduleIfNeeded(
                                        context
                                    )
                                } catch (exception: Exception) {
                                    restoreInProgress = false
                                    restoreError =
                                        exception.localizedMessage ?: tr(
                                            language,
                                            "ප්‍රතිසාධනය සම්පූර්ණ කළ නොහැකි විය.",
                                            "Restore could not be completed."
                                        )

                                    AutoBackupScheduler.scheduleIfNeeded(
                                        context
                                    )
                                }
                            }

                            is DriveRestoreResult.Error -> {
                                restoreInProgress = false
                                restoreError = result.message

                                AutoBackupScheduler.scheduleIfNeeded(
                                    context
                                )
                            }
                        }
                    }
                }


                val driveConsentLauncher =
                    rememberLauncherForActivityResult(
                        contract =
                            ActivityResultContracts.StartIntentSenderForResult()
                    ) { result ->
                        driveAuthorizationLoading = false

                        if (
                            result.resultCode == Activity.RESULT_OK &&
                            result.data != null
                        ) {
                            driveBackupManager.handleAuthorizationIntent(
                                result.data
                            ) { state ->
                                when (state) {
                                    is DriveAuthorizationState.Authorized -> {
                                        markDriveAuthorized()

                                        val shouldBackup =
                                            pendingBackupAfterConsent

                                        val shouldCheckBackup =
                                            pendingBackupCheckAfterConsent

                                        val shouldRestore =
                                            pendingRestoreAfterConsent

                                        pendingBackupAfterConsent = false
                                        pendingBackupCheckAfterConsent = false
                                        pendingRestoreAfterConsent = false

                                        when {
                                            shouldBackup -> {
                                                performBackupWithToken(
                                                    state.accessToken
                                                )
                                            }

                                            shouldRestore -> {
                                                performRestoreWithToken(
                                                    state.accessToken
                                                )
                                            }

                                            shouldCheckBackup -> {
                                                performBackupCheckWithToken(
                                                    state.accessToken
                                                )
                                            }

                                            else -> {
                                                AutoBackupScheduler.scheduleIfNeeded(
                                                    context
                                                )
                                            }
                                        }
                                    }

                                    is DriveAuthorizationState.Error -> {
                                        pendingBackupAfterConsent = false
                                        pendingBackupCheckAfterConsent = false
                                        pendingRestoreAfterConsent = false
                                        driveAccessGranted = false
                                        driveAuthorizationError = state.message
                                    }

                                    is DriveAuthorizationState.NeedsUserConsent -> {
                                        pendingBackupAfterConsent = false
                                        pendingBackupCheckAfterConsent = false
                                        pendingRestoreAfterConsent = false
                                        driveAuthorizationError = tr(
                                            language,
                                            "Google Drive අවසරය සම්පූර්ණ කළ නොහැකි විය.",
                                            "Google Drive permission could not be completed."
                                        )
                                    }
                                }
                            }
                        } else {
                            pendingBackupAfterConsent = false
                            pendingBackupCheckAfterConsent = false
                            pendingRestoreAfterConsent = false
                            driveAuthorizationError = tr(
                                language,
                                "Google Drive අවසරය අවලංගු කරන ලදී.",
                                "Google Drive permission was cancelled."
                            )
                        }
                    }

                fun startGoogleSignIn() {
                    if (googleSignInLoading) return

                    googleSignInLoading = true
                    googleSignInError = null

                    coroutineScope.launch {
                        try {
                            val googleOption =
                                GetSignInWithGoogleOption.Builder(
                                    serverClientId = WEB_CLIENT_ID
                                ).build()

                            val request =
                                GetCredentialRequest.Builder()
                                    .addCredentialOption(googleOption)
                                    .build()

                            val result =
                                credentialManager.getCredential(
                                    context = this@MainActivity,
                                    request = request
                                )

                            val credential = result.credential

                            if (
                                credential is CustomCredential &&
                                credential.type ==
                                GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
                            ) {
                                val googleCredential =
                                    GoogleIdTokenCredential.createFrom(
                                        credential.data
                                    )

                                googleEmail = googleCredential.id
                                googleName = googleCredential.displayName ?: ""
                                googleUniqueId = googleCredential.uniqueId
                                googleSignedIn = true

                                preferences.edit()
                                    .putBoolean("google_signed_in", true)
                                    .putString("google_email", googleEmail)
                                    .putString("google_name", googleName)
                                    .putString("google_unique_id", googleUniqueId)
                                    .apply()

                                googleReturnScreen = null
                                currentScreen = AppScreen.HOME
                                requestCloudCheckAfterSignIn = true
                            } else {
                                googleSignInError = tr(
                                    language,
                                    "Google ගිණුම හඳුනාගත නොහැකි විය.",
                                    "Could not identify the Google account."
                                )
                            }
                        } catch (e: GetCredentialException) {
                            googleSignInError = tr(
                                language,
                                "Google පිවිසුම සම්පූර්ණ කළ නොහැකි විය. නැවත උත්සාහ කරන්න.",
                                "Google sign-in was not completed. Please try again."
                            )
                        } catch (e: Exception) {
                            googleSignInError = e.localizedMessage ?: tr(
                                language,
                                "Google පිවිසුමේ දෝෂයක් ඇති විය.",
                                "An error occurred during Google sign-in."
                            )
                        } finally {
                            googleSignInLoading = false
                        }
                    }
                }

                fun requestDriveAuthorization(
                    startBackupAfterAuthorization: Boolean,
                    checkBackupAfterAuthorization: Boolean = false,
                    restoreAfterAuthorization: Boolean = false
                ) {
                    if (
                        driveAuthorizationLoading ||
                        backupInProgress ||
                        restoreInProgress ||
                        !googleSignedIn
                    ) {
                        return
                    }

                    pendingBackupAfterConsent = startBackupAfterAuthorization
                    pendingBackupCheckAfterConsent = checkBackupAfterAuthorization
                    pendingRestoreAfterConsent = restoreAfterAuthorization
                    driveAuthorizationLoading = true
                    driveAuthorizationError = null
                    backupMessage = null
                    backupError = null

                    driveBackupManager.requestDriveAuthorization { state ->
                        when (state) {
                            is DriveAuthorizationState.Authorized -> {
                                driveAuthorizationLoading = false
                                pendingBackupAfterConsent = false
                                pendingBackupCheckAfterConsent = false
                                pendingRestoreAfterConsent = false
                                markDriveAuthorized()

                                when {
                                    startBackupAfterAuthorization -> {
                                        performBackupWithToken(
                                            state.accessToken
                                        )
                                    }

                                    restoreAfterAuthorization -> {
                                        performRestoreWithToken(
                                            state.accessToken
                                        )
                                    }

                                    checkBackupAfterAuthorization -> {
                                        performBackupCheckWithToken(
                                            state.accessToken
                                        )
                                    }

                                    else -> {
                                        AutoBackupScheduler.scheduleIfNeeded(
                                            context
                                        )
                                    }
                                }
                            }

                            is DriveAuthorizationState.NeedsUserConsent -> {
                                try {
                                    val intentSenderRequest =
                                        IntentSenderRequest.Builder(
                                            state.pendingIntent.intentSender
                                        ).build()

                                    driveConsentLauncher.launch(
                                        intentSenderRequest
                                    )
                                } catch (e: Exception) {
                                    pendingBackupAfterConsent = false
                                    pendingBackupCheckAfterConsent = false
                                    pendingRestoreAfterConsent = false
                                    driveAuthorizationLoading = false
                                    driveAuthorizationError =
                                        e.localizedMessage ?: tr(
                                            language,
                                            "Google Drive අවසර තිරය විවෘත කළ නොහැකි විය.",
                                            "Could not open the Google Drive permission screen."
                                        )
                                }
                            }

                            is DriveAuthorizationState.Error -> {
                                pendingBackupAfterConsent = false
                                pendingBackupCheckAfterConsent = false
                                pendingRestoreAfterConsent = false
                                driveAuthorizationLoading = false
                                driveAccessGranted = false
                                driveAuthorizationError = state.message
                            }
                        }
                    }
                }

                LaunchedEffect(requestCloudCheckAfterSignIn) {
                    if (
                        requestCloudCheckAfterSignIn &&
                        googleSignedIn
                    ) {
                        requestCloudCheckAfterSignIn = false

                        requestDriveAuthorization(
                            startBackupAfterAuthorization = false,
                            checkBackupAfterAuthorization = true
                        )
                    }
                }

                fun createPdfThen(
                    onReady: (java.io.File) -> Unit
                ) {
                    if (pdfExportInProgress) return

                    pdfExportInProgress = true
                    pdfMessage = null
                    pdfError = null

                    val currentLanguage = language
                    val currentProfileName = profileName
                    val currentProfilePhone = profilePhone
                    val currentProfileAddress = profileAddress
                    val currentProfileNic = profileNic
                    val currentGoodDeeds = goodDeeds.toList()

                    coroutineScope.launch {
                        try {
                            val pdfFile =
                                withContext(Dispatchers.IO) {
                                    pdfManager.createPdfFile(
                                        language = currentLanguage,
                                        profileName = currentProfileName,
                                        profilePhone = currentProfilePhone,
                                        profileAddress = currentProfileAddress,
                                        profileNic = currentProfileNic,
                                        goodDeeds = currentGoodDeeds
                                    )
                                }

                            pdfExportInProgress = false
                            onReady(pdfFile)
                        } catch (exception: Exception) {
                            pdfExportInProgress = false
                            pdfError =
                                exception.localizedMessage
                                    ?: tr(
                                        currentLanguage,
                                        "PDF ගොනුව සෑදීමට නොහැකි විය.",
                                        "Could not create the PDF."
                                    )
                        }
                    }
                }

                fun signOutGoogle() {
                    coroutineScope.launch {
                        try {
                            credentialManager.clearCredentialState(
                                ClearCredentialStateRequest()
                            )
                        } catch (_: Exception) {
                        }

                        googleSignedIn = false
                        googleEmail = ""
                        googleName = ""
                        googleUniqueId = ""

                        driveAccessGranted = false
                        driveAuthorizationLoading = false
                        driveAuthorizationError = null

                        backupInProgress = false
                        backupMessage = null
                        backupError = null
                        lastBackupAt = 0L
                        pendingBackupAfterConsent = false
                        pendingBackupCheckAfterConsent = false
                        requestCloudCheckAfterSignIn = false

                        cloudBackupCheckInProgress = false
                        cloudBackupFound = false
                        cloudBackupFileId = null
                        cloudBackupModifiedAt = 0L

                        restoreInProgress = false
                        restoreMessage = null
                        restoreError = null
                        pendingRestoreAfterConsent = false

                        googleReturnScreen = null

                        AutoBackupScheduler.cancelScheduledWork(
                            context
                        )

                        preferences.edit()
                            .remove("google_signed_in")
                            .remove("google_email")
                            .remove("google_name")
                            .remove("google_unique_id")
                            .remove("drive_access_granted")
                            .remove("last_backup_at")
                            .apply()

                        currentScreen = AppScreen.GOOGLE
                    }
                }

                BackHandler(enabled = !showStartupSplash) {
                    when (currentScreen) {
                        AppScreen.ADD -> {
                            currentScreen = AppScreen.HOME
                        }

                        AppScreen.EDIT -> {
                            selectedGoodDeed = null
                            currentScreen = AppScreen.HOME
                        }

                        AppScreen.SETTINGS -> {
                            currentScreen = AppScreen.HOME
                        }

                        AppScreen.PERSONAL_DETAILS -> {
                            currentScreen = AppScreen.HOME
                        }

                        AppScreen.PRINT_EXPORT -> {
                            currentScreen = AppScreen.HOME
                        }

                        AppScreen.LANGUAGE -> {
                            if (savedLanguage != null) {
                                currentScreen = AppScreen.GOOGLE
                            } else {
                                this@MainActivity.moveTaskToBack(true)
                            }
                        }

                        AppScreen.GOOGLE -> {
                            val returnScreen = googleReturnScreen

                            if (returnScreen != null) {
                                googleReturnScreen = null
                                currentScreen = returnScreen
                            } else if (
                                savedLanguage == null &&
                                appLanguage != null
                            ) {
                                currentScreen = AppScreen.LANGUAGE
                            } else {
                                this@MainActivity.moveTaskToBack(true)
                            }
                        }

                        AppScreen.HOME -> {
                            this@MainActivity.moveTaskToBack(true)
                        }
                    }
                }

                if (showStartupSplash) {
                    StartupSplashScreen(
                        language = language
                    )
                } else {
                    when (currentScreen) {
                        AppScreen.LANGUAGE -> {
                            LanguageSelectionScreen(
                                currentLanguage = appLanguage,
                                onContinue = { selectedLanguage ->
                                    appLanguage = selectedLanguage

                                    preferences.edit()
                                        .putString(
                                            "app_language",
                                            selectedLanguage.name
                                        )
                                        .apply()

                                    currentScreen =
                                        if (googleSignedIn) {
                                            AppScreen.HOME
                                        } else {
                                            AppScreen.GOOGLE
                                        }
                                }
                            )
                        }

                        AppScreen.GOOGLE -> {
                            GoogleBackupWelcomeScreen(
                                language = language,
                                isSigningIn = googleSignInLoading,
                                signInError = googleSignInError,
                                onGoogleSignIn = {
                                    startGoogleSignIn()
                                },
                                onSkip = {
                                    googleSignInError = null
                                    currentScreen = AppScreen.HOME
                                },
                                onChangeLanguage = {
                                    currentScreen = AppScreen.LANGUAGE
                                }
                            )
                        }

                        AppScreen.HOME -> {
                            PinPothaHomeScreen(
                                language = language,
                                goodDeeds = goodDeeds,
                                googleSignedIn = googleSignedIn,
                                googleEmail = googleEmail,
                                driveAccessGranted = driveAccessGranted,
                                lastBackupAt = lastBackupAt,
                                autoBackupPending = autoBackupPending,
                                cloudBackupCheckInProgress =
                                    cloudBackupCheckInProgress,
                                driveAuthorizationLoading =
                                    driveAuthorizationLoading,
                                cloudBackupFound = cloudBackupFound,
                                cloudBackupFileId = cloudBackupFileId,
                                cloudBackupModifiedAt =
                                    cloudBackupModifiedAt,
                                restoreInProgress = restoreInProgress,
                                restoreMessage = restoreMessage,
                                onRestoreFromDrive = {
                                    requestDriveAuthorization(
                                        startBackupAfterAuthorization = false,
                                        checkBackupAfterAuthorization = false,
                                        restoreAfterAuthorization = true
                                    )
                                },
                                themeMode = appThemeMode,
                                onThemeChanged = { newThemeMode ->
                                    appThemeMode = newThemeMode

                                    preferences.edit()
                                        .putString(
                                            "app_theme_mode",
                                            newThemeMode.name
                                        )
                                        .apply()
                                },
                                accentColor = appAccentColor,
                                onAccentColorChanged = { newAccent ->
                                    appAccentColor = newAccent

                                    preferences.edit()
                                        .putString(
                                            "app_accent_color",
                                            newAccent.name
                                        )
                                        .apply()
                                },
                                onAddClick = {
                                    currentScreen = AppScreen.ADD
                                },
                                onSettingsClick = {
                                    currentScreen = AppScreen.SETTINGS
                                },
                                onPersonalDetailsClick = {
                                    currentScreen = AppScreen.PERSONAL_DETAILS
                                },
                                onPrintExportClick = {
                                    pdfMessage = null
                                    pdfError = null
                                    currentScreen = AppScreen.PRINT_EXPORT
                                },
                                onLanguageChanged = { newLanguage ->
                                    appLanguage = newLanguage

                                    preferences.edit()
                                        .putString(
                                            "app_language",
                                            newLanguage.name
                                        )
                                        .apply()
                                },
                                onEdit = { deed ->
                                    selectedGoodDeed = deed
                                    currentScreen = AppScreen.EDIT
                                },
                                onDelete = { deed ->
                                    coroutineScope.launch {
                                        dao.deleteGoodDeed(deed)

                                        AutoBackupScheduler.markChangedAndSchedule(
                                            context
                                        )
                                    }
                                }
                            )
                        }

                        AppScreen.ADD -> {
                            GoodDeedFormScreen(
                                language = language,
                                isEditing = false,
                                initialDescription = "",
                                initialDate = LocalDate.now(),
                                initialTime = LocalTime.now()
                                    .withSecond(0)
                                    .withNano(0),
                                onBack = {
                                    currentScreen = AppScreen.HOME
                                },
                                onSave = { description, date, time ->
                                    val timestamp =
                                        LocalDateTime.of(date, time)
                                            .atZone(ZoneId.systemDefault())
                                            .toInstant()
                                            .toEpochMilli()

                                    coroutineScope.launch {
                                        dao.insertGoodDeed(
                                            GoodDeedEntity(
                                                description = description,
                                                deedDateTime = timestamp
                                            )
                                        )

                                        AutoBackupScheduler.markChangedAndSchedule(
                                            context
                                        )
                                    }

                                    currentScreen = AppScreen.HOME
                                }
                            )
                        }

                        AppScreen.EDIT -> {
                            val deed = selectedGoodDeed

                            if (deed == null) {
                                currentScreen = AppScreen.HOME
                            } else {
                                val existingDateTime =
                                    Instant.ofEpochMilli(
                                        deed.deedDateTime
                                    )
                                        .atZone(ZoneId.systemDefault())
                                        .toLocalDateTime()

                                GoodDeedFormScreen(
                                    language = language,
                                    isEditing = true,
                                    initialDescription = deed.description,
                                    initialDate = existingDateTime.toLocalDate(),
                                    initialTime = existingDateTime.toLocalTime(),
                                    onBack = {
                                        selectedGoodDeed = null
                                        currentScreen = AppScreen.HOME
                                    },
                                    onSave = { description, date, time ->
                                        val timestamp =
                                            LocalDateTime.of(date, time)
                                                .atZone(ZoneId.systemDefault())
                                                .toInstant()
                                                .toEpochMilli()

                                        coroutineScope.launch {
                                            dao.updateGoodDeed(
                                                deed.copy(
                                                    description = description,
                                                    deedDateTime = timestamp,
                                                    updatedAt =
                                                        System.currentTimeMillis()
                                                )
                                            )

                                            AutoBackupScheduler.markChangedAndSchedule(
                                                context
                                            )
                                        }

                                        selectedGoodDeed = null
                                        currentScreen = AppScreen.HOME
                                    }
                                )
                            }
                        }

                        AppScreen.SETTINGS -> {
                            SettingsScreen(
                                language = language,
                                profileName = profileName,
                                profilePhone = profilePhone,
                                profileAddress = profileAddress,
                                profileNic = profileNic,
                                googleSignedIn = googleSignedIn,
                                googleEmail = googleEmail,
                                googleName = googleName,
                                driveAccessGranted = driveAccessGranted,
                                driveAuthorizationLoading =
                                    driveAuthorizationLoading,
                                driveAuthorizationError =
                                    driveAuthorizationError,
                                backupInProgress = backupInProgress,
                                backupMessage = backupMessage,
                                backupError = backupError,
                                lastBackupAt = lastBackupAt,
                                autoBackupPending = autoBackupPending,
                                autoBackupError = autoBackupError,
                                cloudBackupFound = cloudBackupFound,
                                restoreInProgress = restoreInProgress,
                                restoreMessage = restoreMessage,
                                restoreError = restoreError,
                                themeMode = appThemeMode,
                                onThemeChanged = { newThemeMode ->
                                    appThemeMode = newThemeMode

                                    preferences.edit()
                                        .putString(
                                            "app_theme_mode",
                                            newThemeMode.name
                                        )
                                        .apply()
                                },
                                accentColor = appAccentColor,
                                onAccentColorChanged = { newAccent ->
                                    appAccentColor = newAccent

                                    preferences.edit()
                                        .putString(
                                            "app_accent_color",
                                            newAccent.name
                                        )
                                        .apply()
                                },
                                onEnableDriveBackup = {
                                    requestDriveAuthorization(
                                        startBackupAfterAuthorization = false,
                                        checkBackupAfterAuthorization = false
                                    )
                                },
                                onBackupNow = {
                                    requestDriveAuthorization(
                                        startBackupAfterAuthorization = true,
                                        checkBackupAfterAuthorization = false
                                    )
                                },
                                onRestoreFromDrive = {
                                    requestDriveAuthorization(
                                        startBackupAfterAuthorization = false,
                                        checkBackupAfterAuthorization = false,
                                        restoreAfterAuthorization = true
                                    )
                                },
                                onPersonalDetailsClick = {
                                    currentScreen =
                                        AppScreen.PERSONAL_DETAILS
                                },
                                onPrintExportClick = {
                                    pdfMessage = null
                                    pdfError = null
                                    currentScreen =
                                        AppScreen.PRINT_EXPORT
                                },
                                onGoogleConnectClick = {
                                    googleReturnScreen = AppScreen.SETTINGS
                                    currentScreen = AppScreen.GOOGLE
                                },
                                onGoogleSignOut = {
                                    signOutGoogle()
                                },
                                onLanguageChanged = { newLanguage ->
                                    appLanguage = newLanguage

                                    preferences.edit()
                                        .putString(
                                            "app_language",
                                            newLanguage.name
                                        )
                                        .apply()
                                },
                                onBack = {
                                    currentScreen = AppScreen.HOME
                                }
                            )
                        }

                        AppScreen.PERSONAL_DETAILS -> {
                            PersonalDetailsScreen(
                                language = language,
                                initialName = profileName,
                                initialPhone = profilePhone,
                                initialAddress = profileAddress,
                                initialNic = profileNic,
                                onSave = { name, phone, address, nic ->
                                    profileName = name.trim()
                                    profilePhone = phone.trim()
                                    profileAddress = address.trim()
                                    profileNic = nic.trim()

                                    preferences.edit()
                                        .putString(
                                            "profile_name",
                                            profileName
                                        )
                                        .putString(
                                            "profile_phone",
                                            profilePhone
                                        )
                                        .putString(
                                            "profile_address",
                                            profileAddress
                                        )
                                        .putString(
                                            "profile_nic",
                                            profileNic
                                        )
                                        .apply()

                                    AutoBackupScheduler.markChangedAndSchedule(
                                        context
                                    )

                                    currentScreen = AppScreen.HOME
                                },
                                onBack = {
                                    currentScreen = AppScreen.HOME
                                }
                            )
                        }

                        AppScreen.PRINT_EXPORT -> {
                            PrintExportScreen(
                                language = language,
                                goodDeedCount = goodDeeds.size,
                                hasPersonalDetails =
                                    profileName.isNotBlank() ||
                                            profilePhone.isNotBlank() ||
                                            profileAddress.isNotBlank() ||
                                            profileNic.isNotBlank(),
                                isWorking = pdfExportInProgress,
                                message = pdfMessage,
                                error = pdfError,
                                onPrintPreview = {
                                    createPdfThen { file ->
                                        pdfManager.printPdf(
                                            pdfFile = file,
                                            language = language
                                        )
                                    }
                                },
                                onSavePdf = {
                                    createPdfThen { file ->
                                        pendingPdfForSave = file
                                        savePdfLauncher.launch(
                                            file.name
                                        )
                                    }
                                },
                                onBack = {
                                    currentScreen = AppScreen.HOME
                                }
                            )
                        }
                    }

                }
            }
        }
    }
}



@Composable
fun CloudBackupActivityStatus(
    language: AppLanguage,
    textSinhala: String,
    textEnglish: String
) {
    val infiniteTransition =
        rememberInfiniteTransition(
            label = "cloudBackupSearch"
        )

    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec =
            infiniteRepeatable(
                animation =
                    tween(
                        durationMillis = 1200,
                        easing = LinearEasing
                    )
            ),
        label = "cloudBackupRotation"
    )

    Surface(
        shape = RoundedCornerShape(50.dp),
        color =
            MaterialTheme.colorScheme.primaryContainer
    ) {
        Row(
            modifier = Modifier.padding(
                horizontal = 11.dp,
                vertical = 6.dp
            ),
            verticalAlignment =
                Alignment.CenterVertically
        ) {
            Icon(
                painter = painterResource(
                    id = R.drawable.ic_sync
                ),
                contentDescription = null,
                modifier = Modifier
                    .size(16.dp)
                    .graphicsLayer(
                        rotationZ = rotation
                    ),
                tint =
                    MaterialTheme.colorScheme.onPrimaryContainer
            )

            Spacer(
                modifier = Modifier.width(7.dp)
            )

            Text(
                text = tr(
                    language,
                    textSinhala,
                    textEnglish
                ),
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color =
                    MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
    }
}

enum class StatusTone {
    SUCCESS,
    WARNING,
    NEUTRAL
}

@Composable
fun StatusChip(
    text: String,
    tone: StatusTone
) {
    val containerColor =
        when (tone) {
            StatusTone.SUCCESS ->
                MaterialTheme.colorScheme.primaryContainer

            StatusTone.WARNING ->
                MaterialTheme.colorScheme.tertiaryContainer

            StatusTone.NEUTRAL ->
                MaterialTheme.colorScheme.secondaryContainer
        }

    val contentColor =
        when (tone) {
            StatusTone.SUCCESS ->
                MaterialTheme.colorScheme.onPrimaryContainer

            StatusTone.WARNING ->
                MaterialTheme.colorScheme.onTertiaryContainer

            StatusTone.NEUTRAL ->
                MaterialTheme.colorScheme.onSecondaryContainer
        }

    Surface(
        shape = RoundedCornerShape(50.dp),
        color = containerColor
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(
                horizontal = 12.dp,
                vertical = 6.dp
            ),
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = contentColor
        )
    }
}


@Composable
fun StartupSplashScreen(
    language: AppLanguage
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding(),
            horizontalAlignment =
                Alignment.CenterHorizontally,
            verticalArrangement =
                Arrangement.Center
        ) {
            Image(
                painter = painterResource(
                    id = R.drawable.pin_potha_logo
                ),
                contentDescription = "Pin Potha",
                modifier = Modifier.size(132.dp)
            )

            Spacer(
                modifier = Modifier.height(16.dp)
            )

            Text(
                text = tr(
                    language,
                    "පින් පොත",
                    "Pin Potha"
                ),
                fontSize = 30.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(
                modifier = Modifier.height(5.dp)
            )

            Text(
                text = "by Dinusha Rukshan",
                fontSize = 14.sp,
                color =
                    MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}


@Composable
fun SettingsSectionHeader(
    iconRes: Int,
    title: String,
    fontSizeValue: Int = 18
) {
    Row(
        verticalAlignment =
            Alignment.CenterVertically
    ) {
        Surface(
            shape = RoundedCornerShape(12.dp),
            color =
                MaterialTheme.colorScheme.primaryContainer
        ) {
            Icon(
                painter = painterResource(
                    id = iconRes
                ),
                contentDescription = null,
                modifier = Modifier
                    .padding(8.dp)
                    .size(20.dp),
                tint =
                    MaterialTheme.colorScheme.onPrimaryContainer
            )
        }

        Spacer(
            modifier = Modifier.width(10.dp)
        )

        Text(
            text = title,
            fontSize = fontSizeValue.sp,
            fontWeight = FontWeight.Bold
        )
    }
}


@Composable
fun AccentColorPicker(
    language: AppLanguage,
    selectedAccent: PinPothaAccent,
    onAccentSelected: (PinPothaAccent) -> Unit
) {
    Text(
        text = tr(
            language,
            "ප්‍රධාන වර්ණය",
            "Accent color"
        ),
        fontSize = 14.sp,
        fontWeight = FontWeight.SemiBold
    )

    Spacer(
        modifier = Modifier.height(10.dp)
    )

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement =
            Arrangement.SpaceEvenly,
        verticalAlignment =
            Alignment.CenterVertically
    ) {
        PinPothaAccent.entries.forEach { accent ->

            val selected =
                accent == selectedAccent

            Surface(
                onClick = {
                    onAccentSelected(accent)
                },
                modifier = Modifier.size(42.dp),
                shape = CircleShape,
                color = accentPreviewColor(accent),
                tonalElevation =
                    if (selected) {
                        5.dp
                    } else {
                        0.dp
                    },
                shadowElevation =
                    if (selected) {
                        4.dp
                    } else {
                        0.dp
                    }
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment =
                        Alignment.Center
                ) {
                    if (selected) {
                        Text(
                            text = "✓",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }

    Spacer(
        modifier = Modifier.height(4.dp)
    )

    Text(
        text = tr(
            language,
            "වර්ණය වෙනස් කළ විට බොත්තම් සහ ප්‍රධාන අංග එම වර්ණයට වෙනස් වේ.",
            "Buttons and key app elements change to the selected color."
        ),
        fontSize = 12.sp,
        color =
            MaterialTheme.colorScheme.onSurfaceVariant
    )
}


@Composable
fun QuickSettingsDrawer(
    language: AppLanguage,
    googleSignedIn: Boolean,
    googleEmail: String,
    driveAccessGranted: Boolean,
    lastBackupAt: Long,
    autoBackupPending: Boolean,
    themeMode: AppThemeMode,
    onThemeChanged: (AppThemeMode) -> Unit,
    accentColor: PinPothaAccent,
    onAccentColorChanged: (PinPothaAccent) -> Unit,
    onManageBackup: () -> Unit,
    onPersonalDetails: () -> Unit,
    onPrintExport: () -> Unit,
    onLanguageChanged: (AppLanguage) -> Unit,
    onClose: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(
                horizontal = 16.dp,
                vertical = 12.dp
            )
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement =
                Arrangement.SpaceBetween,
            verticalAlignment =
                Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment =
                    Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(13.dp),
                    color =
                        MaterialTheme.colorScheme.primaryContainer
                ) {
                    Icon(
                        painter = painterResource(
                            id = R.drawable.ic_settings
                        ),
                        contentDescription = null,
                        modifier = Modifier
                            .padding(10.dp)
                            .size(24.dp),
                        tint =
                            MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }

                Spacer(
                    modifier = Modifier.width(9.dp)
                )

                Column {
                    Text(
                        text = tr(
                            language,
                            "සැකසුම්",
                            "Settings"
                        ),
                        fontSize = 23.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = "by Dinusha Rukshan",
                        fontSize = 11.sp,
                        color =
                            MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            OutlinedButton(
                onClick = onClose,
                modifier = Modifier.height(42.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(
                    tr(
                        language,
                        "වසන්න",
                        "Close"
                    )
                )
            }
        }

        Spacer(
            modifier = Modifier.height(14.dp)
        )

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement =
                Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(
                        defaultElevation = 1.dp
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp)
                    ) {
                        SettingsSectionHeader(
                            iconRes = R.drawable.ic_cloud_backup,
                            title = tr(
                                language,
                                "Google උපස්ථය",
                                "Google Backup"
                            )
                        )

                        Spacer(
                            modifier = Modifier.height(8.dp)
                        )

                        StatusChip(
                            text =
                                when {
                                    googleSignedIn &&
                                            driveAccessGranted &&
                                            autoBackupPending ->
                                        tr(
                                            language,
                                            "වෙනස්කම් උපස්ථ වීමට බලා සිටී",
                                            "Backup pending"
                                        )

                                    googleSignedIn &&
                                            driveAccessGranted ->
                                        tr(
                                            language,
                                            "Google Drive සක්‍රීයයි",
                                            "Google Drive active"
                                        )

                                    googleSignedIn ->
                                        tr(
                                            language,
                                            "Google සම්බන්ධයි",
                                            "Google connected"
                                        )

                                    else ->
                                        tr(
                                            language,
                                            "සම්බන්ධ කර නැත",
                                            "Not connected"
                                        )
                                },
                            tone =
                                when {
                                    googleSignedIn &&
                                            driveAccessGranted &&
                                            autoBackupPending ->
                                        StatusTone.WARNING

                                    googleSignedIn &&
                                            driveAccessGranted ->
                                        StatusTone.SUCCESS

                                    else ->
                                        StatusTone.NEUTRAL
                                }
                        )

                        if (googleEmail.isNotBlank()) {
                            Spacer(
                                modifier = Modifier.height(8.dp)
                            )

                            Text(
                                text = googleEmail,
                                fontSize = 13.sp,
                                color =
                                    MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        if (lastBackupAt > 0L) {
                            Spacer(
                                modifier = Modifier.height(5.dp)
                            )

                            Text(
                                text = tr(
                                    language,
                                    "අවසන් උපස්ථය: ${
                                        formatBackupDateTime(lastBackupAt)
                                    }",
                                    "Last backup: ${
                                        formatBackupDateTime(lastBackupAt)
                                    }"
                                ),
                                fontSize = 12.sp,
                                color =
                                    MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Spacer(
                            modifier = Modifier.height(12.dp)
                        )

                        Button(
                            onClick = onManageBackup,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(
                                painter = painterResource(
                                    id = R.drawable.ic_cloud_backup
                                ),
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )

                            Spacer(
                                modifier = Modifier.width(7.dp)
                            )

                            Text(
                                tr(
                                    language,
                                    "Google උපස්ථය කළමනාකරණය",
                                    "Manage Google Backup"
                                )
                            )
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(
                        defaultElevation = 1.dp
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp)
                    ) {
                        SettingsSectionHeader(
                            iconRes = R.drawable.ic_person,
                            title = tr(
                                language,
                                "පුද්ගලික තොරතුරු",
                                "Personal Details"
                            )
                        )

                        Spacer(
                            modifier = Modifier.height(10.dp)
                        )

                        OutlinedButton(
                            onClick = onPersonalDetails,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(
                                painter = painterResource(
                                    id = R.drawable.ic_person
                                ),
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )

                            Spacer(
                                modifier = Modifier.width(7.dp)
                            )

                            Text(
                                tr(
                                    language,
                                    "විවෘත කරන්න",
                                    "Open Personal Details"
                                )
                            )
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(
                        defaultElevation = 1.dp
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp)
                    ) {
                        SettingsSectionHeader(
                            iconRes = R.drawable.ic_print,
                            title = tr(
                                language,
                                "මුද්‍රණය / PDF",
                                "Print / PDF"
                            )
                        )

                        Spacer(
                            modifier = Modifier.height(10.dp)
                        )

                        OutlinedButton(
                            onClick = onPrintExport,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(
                                painter = painterResource(
                                    id = R.drawable.ic_print
                                ),
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )

                            Spacer(
                                modifier = Modifier.width(7.dp)
                            )

                            Text(
                                tr(
                                    language,
                                    "මුද්‍රණ සහ PDF විකල්ප",
                                    "Open Print / PDF"
                                )
                            )
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(
                        defaultElevation = 1.dp
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp)
                    ) {
                        SettingsSectionHeader(
                            iconRes = R.drawable.ic_language,
                            title = tr(
                                language,
                                "භාෂාව",
                                "Language"
                            )
                        )

                        Spacer(
                            modifier = Modifier.height(10.dp)
                        )

                        if (language == AppLanguage.SINHALA) {
                            Button(
                                onClick = {
                                    onLanguageChanged(
                                        AppLanguage.SINHALA
                                    )
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text("සිංහල ✓")
                            }
                        } else {
                            OutlinedButton(
                                onClick = {
                                    onLanguageChanged(
                                        AppLanguage.SINHALA
                                    )
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text("සිංහල")
                            }
                        }

                        Spacer(
                            modifier = Modifier.height(8.dp)
                        )

                        if (language == AppLanguage.ENGLISH) {
                            Button(
                                onClick = {
                                    onLanguageChanged(
                                        AppLanguage.ENGLISH
                                    )
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text("English ✓")
                            }
                        } else {
                            OutlinedButton(
                                onClick = {
                                    onLanguageChanged(
                                        AppLanguage.ENGLISH
                                    )
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Text("English")
                            }
                        }
                    }
                }
            }


            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(
                        defaultElevation = 1.dp
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp)
                    ) {
                        SettingsSectionHeader(
                            iconRes = R.drawable.ic_theme,
                            title = tr(
                                language,
                                "පෙනුම",
                                "Appearance"
                            )
                        )

                        Spacer(
                            modifier = Modifier.height(6.dp)
                        )

                        Text(
                            text = tr(
                                language,
                                "යෙදුමේ ආලෝක හෝ අඳුරු පෙනුම තෝරන්න.",
                                "Choose a light or dark app appearance."
                            ),
                            fontSize = 13.sp,
                            color =
                                MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(
                            modifier = Modifier.height(12.dp)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement =
                                Arrangement.spacedBy(8.dp)
                        ) {
                            if (
                                themeMode ==
                                AppThemeMode.LIGHT
                            ) {
                                Button(
                                    onClick = {
                                        onThemeChanged(
                                            AppThemeMode.LIGHT
                                        )
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp),
                                    shape =
                                        RoundedCornerShape(14.dp)
                                ) {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id =
                                                    R.drawable.ic_light_mode
                                            ),
                                        contentDescription =
                                            null,
                                        modifier =
                                            Modifier.size(18.dp)
                                    )

                                    Spacer(
                                        modifier =
                                            Modifier.width(6.dp)
                                    )

                                    Text(
                                        tr(
                                            language,
                                            "ආලෝක",
                                            "Light"
                                        )
                                    )
                                }
                            } else {
                                OutlinedButton(
                                    onClick = {
                                        onThemeChanged(
                                            AppThemeMode.LIGHT
                                        )
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp),
                                    shape =
                                        RoundedCornerShape(14.dp)
                                ) {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id =
                                                    R.drawable.ic_light_mode
                                            ),
                                        contentDescription =
                                            null,
                                        modifier =
                                            Modifier.size(18.dp)
                                    )

                                    Spacer(
                                        modifier =
                                            Modifier.width(6.dp)
                                    )

                                    Text(
                                        tr(
                                            language,
                                            "ආලෝක",
                                            "Light"
                                        )
                                    )
                                }
                            }

                            if (
                                themeMode ==
                                AppThemeMode.DARK
                            ) {
                                Button(
                                    onClick = {
                                        onThemeChanged(
                                            AppThemeMode.DARK
                                        )
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp),
                                    shape =
                                        RoundedCornerShape(14.dp)
                                ) {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id =
                                                    R.drawable.ic_dark_mode
                                            ),
                                        contentDescription =
                                            null,
                                        modifier =
                                            Modifier.size(18.dp)
                                    )

                                    Spacer(
                                        modifier =
                                            Modifier.width(6.dp)
                                    )

                                    Text(
                                        tr(
                                            language,
                                            "අඳුරු",
                                            "Dark"
                                        )
                                    )
                                }
                            } else {
                                OutlinedButton(
                                    onClick = {
                                        onThemeChanged(
                                            AppThemeMode.DARK
                                        )
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp),
                                    shape =
                                        RoundedCornerShape(14.dp)
                                ) {
                                    Icon(
                                        painter =
                                            painterResource(
                                                id =
                                                    R.drawable.ic_dark_mode
                                            ),
                                        contentDescription =
                                            null,
                                        modifier =
                                            Modifier.size(18.dp)
                                    )

                                    Spacer(
                                        modifier =
                                            Modifier.width(6.dp)
                                    )

                                    Text(
                                        tr(
                                            language,
                                            "අඳුරු",
                                            "Dark"
                                        )
                                    )
                                }
                            }
                        }

                        Spacer(
                            modifier = Modifier.height(16.dp)
                        )

                        AccentColorPicker(
                            language = language,
                            selectedAccent = accentColor,
                            onAccentSelected =
                                onAccentColorChanged
                        )
                    }
                }
            }

            item {
                Spacer(
                    modifier = Modifier.height(8.dp)
                )
            }
        }
    }
}


@Composable
fun LanguageSelectionScreen(
    currentLanguage: AppLanguage?,
    onContinue: (AppLanguage) -> Unit
) {
    var selectedLanguage by remember(currentLanguage) {
        mutableStateOf(currentLanguage)
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(
                    horizontal = 28.dp,
                    vertical = 18.dp
                ),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceEvenly
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(modifier = Modifier.height(4.dp))

                Image(
                    painter = painterResource(
                        id = R.drawable.pin_potha_logo
                    ),
                    contentDescription = "Pin Potha",
                    modifier = Modifier.size(118.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "පින් පොත",
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = "Pin Potha",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(5.dp))

                Text(
                    text = "by Dinusha Rukshan",
                    fontSize = 15.sp,
                    color =
                        MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "භාෂාව තෝරන්න",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(5.dp))

                Text(
                    text = "Choose Language",
                    fontSize = 19.sp,
                    color =
                        MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(32.dp))

                if (
                    selectedLanguage ==
                    AppLanguage.SINHALA
                ) {
                    Button(
                        onClick = {
                            selectedLanguage =
                                AppLanguage.SINHALA
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(64.dp)
                    ) {
                        Text(
                            text = "සිංහල",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    OutlinedButton(
                        onClick = {
                            selectedLanguage =
                                AppLanguage.SINHALA
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(64.dp)
                    ) {
                        Text(
                            text = "සිංහල",
                            fontSize = 20.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (
                    selectedLanguage ==
                    AppLanguage.ENGLISH
                ) {
                    Button(
                        onClick = {
                            selectedLanguage =
                                AppLanguage.ENGLISH
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(64.dp)
                    ) {
                        Text(
                            text = "English",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                } else {
                    OutlinedButton(
                        onClick = {
                            selectedLanguage =
                                AppLanguage.ENGLISH
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(64.dp)
                    ) {
                        Text(
                            text = "English",
                            fontSize = 20.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(28.dp))

                Button(
                    onClick = {
                        selectedLanguage?.let(onContinue)
                    },
                    enabled = selectedLanguage != null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = "ඉදිරියට / Continue",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Text(
                text = "Free • Open Source • No Ads",
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun GoogleBackupWelcomeScreen(
    language: AppLanguage,
    isSigningIn: Boolean,
    signInError: String?,
    onGoogleSignIn: () -> Unit,
    onSkip: () -> Unit,
    onChangeLanguage: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(
                    start = 24.dp,
                    end = 24.dp,
                    top = 16.dp,
                    bottom = 20.dp
                ),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceEvenly
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    painter = painterResource(
                        id = R.drawable.pin_potha_logo
                    ),
                    contentDescription = "Pin Potha",
                    modifier = Modifier.size(108.dp)
                )

                Spacer(modifier = Modifier.height(7.dp))

                Text(
                    text = tr(
                        language,
                        "පින් පොත",
                        "Pin Potha"
                    ),
                    fontSize = 32.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "by Dinusha Rukshan",
                    fontSize = 15.sp,
                    color =
                        MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = tr(
                        language,
                        "ඔබගේ පින් පොත ආරක්ෂා කරගන්න",
                        "Protect your Pin Potha"
                    ),
                    fontSize = 23.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(24.dp))

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor =
                            MaterialTheme.colorScheme.secondaryContainer
                    )
                ) {
                    Text(
                        text = tr(
                            language,
                            "නිර්දේශිතයි — ඔබගේ පින් පොත ආරක්ෂිතව උපස්ථ කර තබා ගැනීමට Google ගිණුමෙන් පිවිසෙන්න. ඔබගේ දුරකථනය නැති වුවහොත් හෝ වෙනස් කළහොත්, ඔබ සුරැකි පින්කම් නැවත ලබාගත හැක.",
                            "Recommended — Sign in to safely back up your Pin Potha. If you lose or change your phone, your good deeds can be restored."
                        ),
                        modifier = Modifier.padding(20.dp),
                        fontSize = 17.sp,
                        lineHeight = 25.sp
                    )
                }

                if (signInError != null) {
                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = signInError,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.error,
                        textAlign = TextAlign.Center
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                Button(
                    onClick = onGoogleSignIn,
                    enabled = !isSigningIn,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(62.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text =
                            if (isSigningIn) {
                                tr(
                                    language,
                                    "පිවිසෙමින්...",
                                    "Signing in..."
                                )
                            } else {
                                tr(
                                    language,
                                    "Google ගිණුමෙන් පිවිසෙන්න",
                                    "Continue with Google"
                                )
                            },
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedButton(
                    onClick = onSkip,
                    enabled = !isSigningIn,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = tr(
                            language,
                            "දැනට මඟ හරින්න",
                            "Skip for now"
                        ),
                        fontSize = 16.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = tr(
                        language,
                        "ඔබට පසුව සැකසුම් මඟින් Google උපස්ථය සක්‍රීය කළ හැක.",
                        "You can enable Google backup later from Settings."
                    ),
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center,
                    color =
                        MaterialTheme.colorScheme.onSurfaceVariant
                )

                TextButton(
                    onClick = onChangeLanguage,
                    enabled = !isSigningIn
                ) {
                    Text(
                        text = tr(
                            language,
                            "භාෂාව වෙනස් කරන්න",
                            "Change language"
                        )
                    )
                }
            }

            Text(
                text = tr(
                    language,
                    "නොමිලේ • විවෘත මූලාශ්‍ර • දැන්වීම් නැත",
                    "Free • Open Source • No Ads"
                ),
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun PinPothaHomeScreen(
    language: AppLanguage,
    goodDeeds: List<GoodDeedEntity>,
    googleSignedIn: Boolean,
    googleEmail: String,
    driveAccessGranted: Boolean,
    lastBackupAt: Long,
    autoBackupPending: Boolean,
    cloudBackupCheckInProgress: Boolean,
    driveAuthorizationLoading: Boolean,
    cloudBackupFound: Boolean,
    cloudBackupFileId: String?,
    cloudBackupModifiedAt: Long,
    restoreInProgress: Boolean,
    restoreMessage: String?,
    onRestoreFromDrive: () -> Unit,
    themeMode: AppThemeMode,
    onThemeChanged: (AppThemeMode) -> Unit,
    accentColor: PinPothaAccent,
    onAccentColorChanged: (PinPothaAccent) -> Unit,
    onAddClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onPersonalDetailsClick: () -> Unit,
    onPrintExportClick: () -> Unit,
    onLanguageChanged: (AppLanguage) -> Unit,
    onEdit: (GoodDeedEntity) -> Unit,
    onDelete: (GoodDeedEntity) -> Unit
) {
    val context = LocalContext.current

    val cloudSearchActive =
        googleSignedIn &&
                (
                        driveAuthorizationLoading ||
                                cloudBackupCheckInProgress
                        )

    var showRestoreOfferDialog by remember {
        mutableStateOf(false)
    }

    var lastPromptedBackupId by remember {
        mutableStateOf<String?>(null)
    }

    LaunchedEffect(
        cloudBackupFound,
        cloudBackupFileId,
        goodDeeds.isEmpty(),
        restoreInProgress
    ) {
        val backupId =
            cloudBackupFileId

        if (
            cloudBackupFound &&
            !restoreInProgress &&
            goodDeeds.isEmpty() &&
            !backupId.isNullOrBlank() &&
            lastPromptedBackupId != backupId
        ) {
            lastPromptedBackupId = backupId
            showRestoreOfferDialog = true
        }
    }

    val drawerState =
        rememberDrawerState(
            initialValue = DrawerValue.Closed
        )

    val drawerScope =
        rememberCoroutineScope()

    BackHandler(
        enabled = drawerState.isOpen
    ) {
        drawerScope.launch {
            drawerState.close()
        }
    }

    var searchText by remember { mutableStateOf("") }
    var dateFilter by remember {
        mutableStateOf(DateFilter.ALL)
    }

    var customFrom by remember {
        mutableStateOf<LocalDate?>(null)
    }

    var customTo by remember {
        mutableStateOf<LocalDate?>(null)
    }

    val today = LocalDate.now()

    val dateFormatter =
        DateTimeFormatter.ofPattern("dd MMM yyyy")

    val filteredGoodDeeds =
        goodDeeds.filter { deed ->
            val deedDate =
                Instant.ofEpochMilli(deed.deedDateTime)
                    .atZone(ZoneId.systemDefault())
                    .toLocalDate()

            val searchMatches =
                searchText.isBlank() ||
                        deed.description.contains(
                            searchText.trim(),
                            ignoreCase = true
                        )

            val dateMatches =
                when (dateFilter) {
                    DateFilter.ALL -> true

                    DateFilter.THIS_MONTH ->
                        deedDate.year == today.year &&
                                deedDate.monthValue ==
                                today.monthValue

                    DateFilter.THIS_YEAR ->
                        deedDate.year == today.year

                    DateFilter.CUSTOM -> {
                        val afterStart =
                            customFrom == null ||
                                    !deedDate.isBefore(customFrom)

                        val beforeEnd =
                            customTo == null ||
                                    !deedDate.isAfter(customTo)

                        afterStart && beforeEnd
                    }
                }

            searchMatches && dateMatches
        }

    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Rtl
    ) {
        ModalNavigationDrawer(
            drawerState = drawerState,
            gesturesEnabled = true,
            drawerContent = {
                ModalDrawerSheet(
                    modifier =
                        Modifier.fillMaxWidth(0.88f)
                ) {
                    CompositionLocalProvider(
                        LocalLayoutDirection provides LayoutDirection.Ltr
                    ) {
                        QuickSettingsDrawer(
                            language = language,
                            googleSignedIn = googleSignedIn,
                            googleEmail = googleEmail,
                            driveAccessGranted = driveAccessGranted,
                            lastBackupAt = lastBackupAt,
                            autoBackupPending = autoBackupPending,
                            themeMode = themeMode,
                            onThemeChanged = onThemeChanged,
                            accentColor = accentColor,
                            onAccentColorChanged =
                                onAccentColorChanged,
                            onManageBackup = {
                                drawerScope.launch {
                                    drawerState.close()
                                    onSettingsClick()
                                }
                            },
                            onPersonalDetails = {
                                drawerScope.launch {
                                    drawerState.close()
                                    onPersonalDetailsClick()
                                }
                            },
                            onPrintExport = {
                                drawerScope.launch {
                                    drawerState.close()
                                    onPrintExportClick()
                                }
                            },
                            onLanguageChanged = onLanguageChanged,
                            onClose = {
                                drawerScope.launch {
                                    drawerState.close()
                                }
                            }
                        )
                    }
                }
            }
        ) {
            CompositionLocalProvider(
                LocalLayoutDirection provides LayoutDirection.Ltr
            ) {
                Scaffold(
                    topBar = {
                        Surface(tonalElevation = 2.dp) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .statusBarsPadding()
                                    .padding(
                                        start = 16.dp,
                                        end = 10.dp,
                                        top = 6.dp,
                                        bottom = 8.dp
                                    ),
                                horizontalArrangement =
                                    Arrangement.SpaceBetween,
                                verticalAlignment =
                                    Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment =
                                        Alignment.CenterVertically
                                ) {
                                    Image(
                                        painter = painterResource(
                                            id = R.drawable.pin_potha_logo
                                        ),
                                        contentDescription = "Pin Potha",
                                        modifier = Modifier.size(46.dp)
                                    )

                                    Spacer(
                                        modifier = Modifier.width(10.dp)
                                    )

                                    Column {
                                        Text(
                                            text = tr(
                                                language,
                                                "පින් පොත",
                                                "Pin Potha"
                                            ),
                                            fontSize = 23.sp,
                                            fontWeight = FontWeight.Bold
                                        )

                                        Text(
                                            text = "by Dinusha Rukshan",
                                            fontSize = 11.sp,
                                            color =
                                                MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                OutlinedButton(
                                    onClick = {
                                        drawerScope.launch {
                                            drawerState.open()
                                        }
                                    },
                                    modifier = Modifier.size(44.dp),
                                    shape = RoundedCornerShape(14.dp),
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Icon(
                                        painter = painterResource(
                                            id = R.drawable.ic_settings
                                        ),
                                        contentDescription = tr(
                                            language,
                                            "සැකසුම්",
                                            "Settings"
                                        ),
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }
                        }
                    },
                    bottomBar = {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .navigationBarsPadding(),
                            tonalElevation = 3.dp
                        ) {
                            Button(
                                onClick = onAddClick,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(
                                        start = 16.dp,
                                        end = 16.dp,
                                        top = 12.dp,
                                        bottom = 12.dp
                                    )
                                    .height(64.dp),
                                shape = RoundedCornerShape(16.dp)
                            ) {
                                Text(
                                    text = tr(
                                        language,
                                        "+ පිනක් එක් කරන්න",
                                        "+ Add Good Deed"
                                    ),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .padding(horizontal = 18.dp),
                        verticalArrangement =
                            Arrangement.spacedBy(12.dp)
                    ) {
                        item {
                            Spacer(modifier = Modifier.height(6.dp))

                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(20.dp),
                                elevation = CardDefaults.cardElevation(
                                    defaultElevation = 1.dp
                                ),
                                colors = CardDefaults.cardColors(
                                    containerColor =
                                        MaterialTheme.colorScheme.secondaryContainer
                                )
                            ) {
                                Column(
                                    modifier = Modifier.padding(16.dp)
                                ) {
                                    when {
                                        cloudSearchActive -> {
                                            CloudBackupActivityStatus(
                                                language = language,
                                                textSinhala =
                                                    "Google Drive උපස්ථ සොයමින්...",
                                                textEnglish =
                                                    "Checking Google Drive backup..."
                                            )
                                        }

                                        restoreInProgress -> {
                                            CloudBackupActivityStatus(
                                                language = language,
                                                textSinhala =
                                                    "උපස්ථය ප්‍රතිසාධනය කරමින්...",
                                                textEnglish =
                                                    "Restoring backup..."
                                            )
                                        }

                                        cloudBackupFound &&
                                                goodDeeds.isEmpty() -> {
                                            StatusChip(
                                                text = tr(
                                                    language,
                                                    "උපස්ථයක් තිබේ",
                                                    "Backup available"
                                                ),
                                                tone = StatusTone.WARNING
                                            )
                                        }

                                        restoreMessage != null -> {
                                            StatusChip(
                                                text = tr(
                                                    language,
                                                    "ප්‍රතිසාධනය සාර්ථකයි",
                                                    "Restore completed"
                                                ),
                                                tone = StatusTone.SUCCESS
                                            )
                                        }

                                        else -> {
                                            StatusChip(
                                                text =
                                                    when {
                                                        googleSignedIn &&
                                                                driveAccessGranted &&
                                                                autoBackupPending ->
                                                            tr(
                                                                language,
                                                                "උපස්ථය බලා සිටී",
                                                                "Backup pending"
                                                            )

                                                        googleSignedIn &&
                                                                driveAccessGranted &&
                                                                lastBackupAt > 0L ->
                                                            tr(
                                                                language,
                                                                "සියල්ල උපස්ථ කර ඇත",
                                                                "Backed up"
                                                            )

                                                        googleSignedIn &&
                                                                driveAccessGranted ->
                                                            tr(
                                                                language,
                                                                "උපස්ථය සූදානම්",
                                                                "Backup ready"
                                                            )

                                                        googleSignedIn ->
                                                            tr(
                                                                language,
                                                                "Google සම්බන්ධයි",
                                                                "Google connected"
                                                            )

                                                        else ->
                                                            tr(
                                                                language,
                                                                "උපස්ථය අක්‍රීයයි",
                                                                "Backup off"
                                                            )
                                                    },
                                                tone =
                                                    when {
                                                        googleSignedIn &&
                                                                driveAccessGranted &&
                                                                autoBackupPending ->
                                                            StatusTone.WARNING

                                                        googleSignedIn &&
                                                                driveAccessGranted ->
                                                            StatusTone.SUCCESS

                                                        else ->
                                                            StatusTone.NEUTRAL
                                                    }
                                            )
                                        }
                                    }

                                    Spacer(
                                        modifier = Modifier.height(9.dp)
                                    )

                                    when {
                                        googleSignedIn &&
                                                driveAccessGranted -> {
                                            Text(
                                                text = tr(
                                                    language,
                                                    "Google Drive උපස්ථය සක්‍රීයයි",
                                                    "Google Drive backup enabled"
                                                ),
                                                fontSize = 16.sp,
                                                fontWeight =
                                                    FontWeight.SemiBold
                                            )

                                            if (googleEmail.isNotBlank()) {
                                                Spacer(
                                                    modifier =
                                                        Modifier.height(4.dp)
                                                )

                                                Text(
                                                    text = googleEmail,
                                                    fontSize = 13.sp
                                                )
                                            }

                                            Spacer(
                                                modifier =
                                                    Modifier.height(5.dp)
                                            )

                                            if (lastBackupAt > 0L) {
                                                Text(
                                                    text = tr(
                                                        language,
                                                        "අවසන් උපස්ථය: ${
                                                            formatBackupDateTime(
                                                                lastBackupAt
                                                            )
                                                        }",
                                                        "Last backup: ${
                                                            formatBackupDateTime(
                                                                lastBackupAt
                                                            )
                                                        }"
                                                    ),
                                                    fontSize = 13.sp
                                                )
                                            } else {
                                                Text(
                                                    text = tr(
                                                        language,
                                                        "තවම උපස්ථයක් කර නැත. සැකසුම් වෙතින් Backup Now භාවිතා කරන්න.",
                                                        "No backup has been created yet. Use Backup Now in Settings."
                                                    ),
                                                    fontSize = 13.sp
                                                )
                                            }
                                        }

                                        googleSignedIn -> {
                                            Text(
                                                text = tr(
                                                    language,
                                                    "Google ගිණුම සම්බන්ධ කර ඇත",
                                                    "Google account connected"
                                                ),
                                                fontSize = 16.sp,
                                                fontWeight =
                                                    FontWeight.SemiBold
                                            )

                                            if (googleEmail.isNotBlank()) {
                                                Spacer(
                                                    modifier =
                                                        Modifier.height(4.dp)
                                                )

                                                Text(
                                                    text = googleEmail,
                                                    fontSize = 13.sp
                                                )
                                            }

                                            Spacer(
                                                modifier =
                                                    Modifier.height(5.dp)
                                            )

                                            Text(
                                                text = tr(
                                                    language,
                                                    "Drive උපස්ථ අවසරය තවම සක්‍රීය කර නැත.",
                                                    "Drive backup permission has not been enabled yet."
                                                ),
                                                fontSize = 13.sp
                                            )
                                        }

                                        else -> {
                                            Text(
                                                text = tr(
                                                    language,
                                                    "Google Drive උපස්ථය සක්‍රීය කර නැත",
                                                    "Google Drive backup is not enabled"
                                                ),
                                                fontSize = 16.sp,
                                                fontWeight =
                                                    FontWeight.SemiBold
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        item {
                            OutlinedTextField(
                                value = searchText,
                                onValueChange = {
                                    searchText = it
                                },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                label = {
                                    Text(
                                        text = tr(
                                            language,
                                            "පින්කම් සොයන්න",
                                            "Search good deeds"
                                        )
                                    )
                                },
                                shape = RoundedCornerShape(16.dp)
                            )
                        }

                        item {
                            Text(
                                text = tr(
                                    language,
                                    "දිනය අනුව සොයන්න",
                                    "Filter by date"
                                ),
                                fontSize = 17.sp,
                                fontWeight = FontWeight.SemiBold
                            )

                            Spacer(modifier = Modifier.height(7.dp))

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(
                                        rememberScrollState()
                                    ),
                                horizontalArrangement =
                                    Arrangement.spacedBy(8.dp)
                            ) {
                                FilterChip(
                                    selected =
                                        dateFilter == DateFilter.ALL,
                                    onClick = {
                                        dateFilter = DateFilter.ALL
                                    },
                                    label = {
                                        Text(
                                            tr(
                                                language,
                                                "සියල්ල",
                                                "All"
                                            )
                                        )
                                    }
                                )

                                FilterChip(
                                    selected =
                                        dateFilter ==
                                                DateFilter.THIS_MONTH,
                                    onClick = {
                                        dateFilter =
                                            DateFilter.THIS_MONTH
                                    },
                                    label = {
                                        Text(
                                            tr(
                                                language,
                                                "මෙම මාසය",
                                                "This Month"
                                            )
                                        )
                                    }
                                )

                                FilterChip(
                                    selected =
                                        dateFilter ==
                                                DateFilter.THIS_YEAR,
                                    onClick = {
                                        dateFilter =
                                            DateFilter.THIS_YEAR
                                    },
                                    label = {
                                        Text(
                                            tr(
                                                language,
                                                "මෙම වසර",
                                                "This Year"
                                            )
                                        )
                                    }
                                )

                                FilterChip(
                                    selected =
                                        dateFilter ==
                                                DateFilter.CUSTOM,
                                    onClick = {
                                        dateFilter = DateFilter.CUSTOM
                                    },
                                    label = {
                                        Text(
                                            tr(
                                                language,
                                                "අභිරුචි",
                                                "Custom"
                                            )
                                        )
                                    }
                                )
                            }
                        }

                        if (dateFilter == DateFilter.CUSTOM) {
                            item {
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(16.dp),
                                        verticalArrangement =
                                            Arrangement.spacedBy(10.dp)
                                    ) {
                                        Text(
                                            text = tr(
                                                language,
                                                "දිනයන් තෝරන්න",
                                                "Choose dates"
                                            ),
                                            fontSize = 17.sp,
                                            fontWeight =
                                                FontWeight.SemiBold
                                        )

                                        OutlinedButton(
                                            onClick = {
                                                val initial =
                                                    customFrom ?: today

                                                DatePickerDialog(
                                                    context,
                                                    { _, year, month, day ->
                                                        val chosen =
                                                            LocalDate.of(
                                                                year,
                                                                month + 1,
                                                                day
                                                            )

                                                        customFrom = chosen

                                                        if (
                                                            customTo != null &&
                                                            customTo!!.isBefore(
                                                                chosen
                                                            )
                                                        ) {
                                                            customTo = chosen
                                                        }
                                                    },
                                                    initial.year,
                                                    initial.monthValue - 1,
                                                    initial.dayOfMonth
                                                ).show()
                                            },
                                            modifier =
                                                Modifier.fillMaxWidth()
                                        ) {
                                            Text(
                                                text =
                                                    if (customFrom == null) {
                                                        tr(
                                                            language,
                                                            "ආරම්භක දිනය",
                                                            "Start date"
                                                        )
                                                    } else {
                                                        tr(
                                                            language,
                                                            "සිට: ${
                                                                customFrom!!.format(
                                                                    dateFormatter
                                                                )
                                                            }",
                                                            "From: ${
                                                                customFrom!!.format(
                                                                    dateFormatter
                                                                )
                                                            }"
                                                        )
                                                    }
                                            )
                                        }

                                        OutlinedButton(
                                            onClick = {
                                                val initial =
                                                    customTo ?: today

                                                DatePickerDialog(
                                                    context,
                                                    { _, year, month, day ->
                                                        val chosen =
                                                            LocalDate.of(
                                                                year,
                                                                month + 1,
                                                                day
                                                            )

                                                        customTo = chosen

                                                        if (
                                                            customFrom != null &&
                                                            customFrom!!.isAfter(
                                                                chosen
                                                            )
                                                        ) {
                                                            customFrom = chosen
                                                        }
                                                    },
                                                    initial.year,
                                                    initial.monthValue - 1,
                                                    initial.dayOfMonth
                                                ).show()
                                            },
                                            modifier =
                                                Modifier.fillMaxWidth()
                                        ) {
                                            Text(
                                                text =
                                                    if (customTo == null) {
                                                        tr(
                                                            language,
                                                            "අවසාන දිනය",
                                                            "End date"
                                                        )
                                                    } else {
                                                        tr(
                                                            language,
                                                            "දක්වා: ${
                                                                customTo!!.format(
                                                                    dateFormatter
                                                                )
                                                            }",
                                                            "To: ${
                                                                customTo!!.format(
                                                                    dateFormatter
                                                                )
                                                            }"
                                                        )
                                                    }
                                            )
                                        }

                                        if (
                                            customFrom != null ||
                                            customTo != null
                                        ) {
                                            TextButton(
                                                onClick = {
                                                    customFrom = null
                                                    customTo = null
                                                }
                                            ) {
                                                Text(
                                                    tr(
                                                        language,
                                                        "දිනයන් ඉවත් කරන්න",
                                                        "Clear dates"
                                                    )
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        if (goodDeeds.isEmpty()) {
                            item {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(
                                            top = 38.dp,
                                            bottom = 24.dp
                                        ),
                                    horizontalAlignment =
                                        Alignment.CenterHorizontally
                                ) {
                                    Image(
                                        painter = painterResource(
                                            id = R.drawable.pin_potha_logo
                                        ),
                                        contentDescription = "Pin Potha",
                                        modifier = Modifier.size(86.dp)
                                    )

                                    Spacer(
                                        modifier = Modifier.height(12.dp)
                                    )

                                    Text(
                                        text = tr(
                                            language,
                                            "ඔබේ පින් පොත තවම හිස්",
                                            "Your Pin Potha is empty"
                                        ),
                                        fontSize = 21.sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center
                                    )

                                    Spacer(
                                        modifier = Modifier.height(6.dp)
                                    )

                                    Text(
                                        text = tr(
                                            language,
                                            "ඔබ කළ පළමු පින්කම පහළ බොත්තමෙන් සටහන් කරන්න.",
                                            "Record your first good deed using the button below."
                                        ),
                                        modifier = Modifier.padding(
                                            horizontal = 26.dp
                                        ),
                                        fontSize = 14.sp,
                                        color =
                                            MaterialTheme.colorScheme.onSurfaceVariant,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        } else if (filteredGoodDeeds.isEmpty()) {
                            item {
                                Text(
                                    text = tr(
                                        language,
                                        "ගැළපෙන පින්කම් හමු නොවීය",
                                        "No matching good deeds found"
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 35.dp),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    textAlign = TextAlign.Center
                                )
                            }
                        } else {
                            item {
                                Text(
                                    text = tr(
                                        language,
                                        "ඔබගේ පින්කම්",
                                        "Your Good Deeds"
                                    ),
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                Text(
                                    text = tr(
                                        language,
                                        "පින්කම් ${filteredGoodDeeds.size}",
                                        "${filteredGoodDeeds.size} good deeds"
                                    ),
                                    fontSize = 14.sp,
                                    color =
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            items(
                                items = filteredGoodDeeds,
                                key = { it.id }
                            ) { deed ->
                                GoodDeedCard(
                                    language = language,
                                    deed = deed,
                                    onEdit = {
                                        onEdit(deed)
                                    },
                                    onDelete = {
                                        onDelete(deed)
                                    }
                                )
                            }
                        }

                        item {
                            Spacer(modifier = Modifier.height(16.dp))
                        }
                    }
                }
            }
        }
    }


    if (showRestoreOfferDialog) {
        AlertDialog(
            onDismissRequest = {
                showRestoreOfferDialog = false
            },
            title = {
                Text(
                    text = tr(
                        language,
                        "Google Drive උපස්ථයක් හමු විය",
                        "Google Drive Backup Found"
                    ),
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column {
                    Text(
                        text = tr(
                            language,
                            "ඔබගේ පෙර සුරැකි පින්කම් මෙම උපාංගයට නැවත ලබාගත හැක.",
                            "Your previously saved good deeds can be restored to this device."
                        ),
                        fontSize = 16.sp
                    )

                    if (cloudBackupModifiedAt > 0L) {
                        Spacer(
                            modifier = Modifier.height(10.dp)
                        )

                        Text(
                            text = tr(
                                language,
                                "උපස්ථ දිනය: ${
                                    formatBackupDateTime(
                                        cloudBackupModifiedAt
                                    )
                                }",
                                "Backup date: ${
                                    formatBackupDateTime(
                                        cloudBackupModifiedAt
                                    )
                                }"
                            ),
                            fontSize = 13.sp,
                            color =
                                MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(
                        modifier = Modifier.height(10.dp)
                    )

                    Text(
                        text = tr(
                            language,
                            "ප්‍රතිසාධනය කිරීමෙන් දුරකථනයේ දත්ත ආරක්ෂිතව ඒකාබද්ධ කරනු ඇත.",
                            "Restore safely merges the cloud backup with this phone."
                        ),
                        fontSize = 13.sp,
                        color =
                            MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showRestoreOfferDialog = false
                        onRestoreFromDrive()
                    }
                ) {
                    Text(
                        tr(
                            language,
                            "දැන් ප්‍රතිසාධනය කරන්න",
                            "Restore Now"
                        )
                    )
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        showRestoreOfferDialog = false
                    }
                ) {
                    Text(
                        tr(
                            language,
                            "දැනට නොවේ",
                            "Not Now"
                        )
                    )
                }
            }
        )
    }

}

@Composable
fun GoodDeedCard(
    language: AppLanguage,
    deed: GoodDeedEntity,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    var showDeleteDialog by remember(deed.id) {
        mutableStateOf(false)
    }

    val dateTime =
        remember(deed.deedDateTime) {
            Instant.ofEpochMilli(
                deed.deedDateTime
            )
                .atZone(ZoneId.systemDefault())
                .toLocalDateTime()
        }

    val dateFormatter =
        DateTimeFormatter.ofPattern("dd MMM yyyy")

    val timeFormatter =
        DateTimeFormatter.ofPattern("hh:mm a")

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 2.dp
        )
    ) {
        Column(
            modifier = Modifier.padding(19.dp)
        ) {
            Text(
                text = deed.description,
                fontSize = 19.sp,
                fontWeight = FontWeight.SemiBold,
                lineHeight = 27.sp
            )

            Spacer(
                modifier = Modifier.height(9.dp)
            )

            Text(
                text =
                    "${dateTime.toLocalDate().format(dateFormatter)} • ${
                        dateTime.toLocalTime().format(timeFormatter)
                    }",
                fontSize = 13.sp,
                color =
                    MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(
                modifier = Modifier.height(14.dp)
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement =
                    Arrangement.SpaceBetween,
                verticalAlignment =
                    Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = onEdit,
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(
                        painter = painterResource(
                            id = R.drawable.ic_edit
                        ),
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )

                    Spacer(
                        modifier = Modifier.width(6.dp)
                    )

                    Text(
                        text = tr(
                            language,
                            "සංස්කරණය",
                            "Edit"
                        )
                    )
                }

                TextButton(
                    onClick = {
                        showDeleteDialog = true
                    }
                ) {
                    Icon(
                        painter = painterResource(
                            id = R.drawable.ic_delete
                        ),
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )

                    Spacer(
                        modifier = Modifier.width(5.dp)
                    )

                    Text(
                        text = tr(
                            language,
                            "මකන්න",
                            "Delete"
                        )
                    )
                }
            }
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = {
                showDeleteDialog = false
            },
            title = {
                Text(
                    text = tr(
                        language,
                        "පින්කම මකා දමන්නද?",
                        "Delete Good Deed?"
                    ),
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(
                    text = tr(
                        language,
                        "මෙම පින්කම ස්ථිරවම මකා දමනු ඇත.",
                        "This good deed will be permanently deleted."
                    ),
                    fontSize = 16.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteDialog = false
                        onDelete()
                    }
                ) {
                    Text(
                        tr(
                            language,
                            "මකන්න",
                            "Delete"
                        )
                    )
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        showDeleteDialog = false
                    }
                ) {
                    Text(
                        tr(
                            language,
                            "අවලංගු",
                            "Cancel"
                        )
                    )
                }
            }
        )
    }
}

@Composable
fun GoodDeedFormScreen(
    language: AppLanguage,
    isEditing: Boolean,
    initialDescription: String,
    initialDate: LocalDate,
    initialTime: LocalTime,
    onBack: () -> Unit,
    onSave: (
        String,
        LocalDate,
        LocalTime
    ) -> Unit
) {
    val context = LocalContext.current

    var description by remember(initialDescription) {
        mutableStateOf(initialDescription)
    }

    var selectedDate by remember(initialDate) {
        mutableStateOf(initialDate)
    }

    var selectedTime by remember(initialTime) {
        mutableStateOf(initialTime)
    }

    val dateFormatter =
        DateTimeFormatter.ofPattern("dd MMM yyyy")

    val timeFormatter =
        DateTimeFormatter.ofPattern("hh:mm a")

    Scaffold(
        topBar = {
            Surface(tonalElevation = 2.dp) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text =
                            if (isEditing) {
                                tr(
                                    language,
                                    "පින්කම සංස්කරණය කරන්න",
                                    "Edit Good Deed"
                                )
                            } else {
                                tr(
                                    language,
                                    "පිනක් එක් කරන්න",
                                    "Add Good Deed"
                                )
                            },
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = "by Dinusha Rukshan",
                        fontSize = 12.sp,
                        color =
                            MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        },
        bottomBar = {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .imePadding(),
                tonalElevation = 3.dp
            ) {
                Button(
                    onClick = {
                        if (description.isNotBlank()) {
                            onSave(
                                description.trim(),
                                selectedDate,
                                selectedTime
                            )
                        }
                    },
                    enabled = description.isNotBlank(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(
                            start = 16.dp,
                            end = 16.dp,
                            top = 10.dp,
                            bottom = 10.dp
                        )
                        .height(64.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text =
                            if (isEditing) {
                                tr(
                                    language,
                                    "වෙනස්කම් සුරකින්න",
                                    "Save Changes"
                                )
                            } else {
                                tr(
                                    language,
                                    "සුරකින්න",
                                    "Save Good Deed"
                                )
                            },
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(20.dp),
            verticalArrangement =
                Arrangement.spacedBy(18.dp)
        ) {
            item {
                Text(
                    text = tr(
                        language,
                        "ඔබ කළ පින්කම",
                        "What good deed did you do?"
                    ),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            item {
                OutlinedTextField(
                    value = description,
                    onValueChange = {
                        description = it
                    },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 4,
                    maxLines = 8,
                    placeholder = {
                        Text(
                            text = tr(
                                language,
                                "මෙහි පින්කම ලියන්න...",
                                "Write your good deed here..."
                            )
                        )
                    },
                    shape = RoundedCornerShape(16.dp)
                )
            }

            item {
                Text(
                    text = tr(
                        language,
                        "දිනය",
                        "Date"
                    ),
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(7.dp))

                OutlinedButton(
                    onClick = {
                        DatePickerDialog(
                            context,
                            { _, year, month, day ->
                                selectedDate =
                                    LocalDate.of(
                                        year,
                                        month + 1,
                                        day
                                    )
                            },
                            selectedDate.year,
                            selectedDate.monthValue - 1,
                            selectedDate.dayOfMonth
                        ).show()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp)
                ) {
                    Text(
                        text =
                            selectedDate.format(
                                dateFormatter
                            ),
                        fontSize = 17.sp
                    )
                }
            }

            item {
                Text(
                    text = tr(
                        language,
                        "වේලාව",
                        "Time"
                    ),
                    fontSize = 17.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(7.dp))

                OutlinedButton(
                    onClick = {
                        TimePickerDialog(
                            context,
                            { _, hour, minute ->
                                selectedTime =
                                    LocalTime.of(
                                        hour,
                                        minute
                                    )
                            },
                            selectedTime.hour,
                            selectedTime.minute,
                            false
                        ).show()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp)
                ) {
                    Text(
                        text =
                            selectedTime.format(
                                timeFormatter
                            ),
                        fontSize = 17.sp
                    )
                }
            }

            item {
                OutlinedButton(
                    onClick = onBack,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                ) {
                    Text(
                        text = tr(
                            language,
                            "ආපසු",
                            "Back"
                        ),
                        fontSize = 16.sp
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(4.dp))
            }
        }
    }
}

@Composable
fun SettingsScreen(
    language: AppLanguage,
    profileName: String,
    profilePhone: String,
    profileAddress: String,
    profileNic: String,
    googleSignedIn: Boolean,
    googleEmail: String,
    googleName: String,
    driveAccessGranted: Boolean,
    driveAuthorizationLoading: Boolean,
    driveAuthorizationError: String?,
    backupInProgress: Boolean,
    backupMessage: String?,
    backupError: String?,
    lastBackupAt: Long,
    autoBackupPending: Boolean,
    autoBackupError: String?,
    cloudBackupFound: Boolean,
    restoreInProgress: Boolean,
    restoreMessage: String?,
    restoreError: String?,
    themeMode: AppThemeMode,
    onThemeChanged: (AppThemeMode) -> Unit,
    accentColor: PinPothaAccent,
    onAccentColorChanged: (PinPothaAccent) -> Unit,
    onEnableDriveBackup: () -> Unit,
    onBackupNow: () -> Unit,
    onRestoreFromDrive: () -> Unit,
    onPersonalDetailsClick: () -> Unit,
    onPrintExportClick: () -> Unit,
    onGoogleConnectClick: () -> Unit,
    onGoogleSignOut: () -> Unit,
    onLanguageChanged: (AppLanguage) -> Unit,
    onBack: () -> Unit
) {
    val hasPersonalDetails =
        profileName.isNotBlank() ||
                profilePhone.isNotBlank() ||
                profileAddress.isNotBlank() ||
                profileNic.isNotBlank()

    var showSignOutDialog by remember {
        mutableStateOf(false)
    }

    var showRestoreDialog by remember {
        mutableStateOf(false)
    }

    Scaffold(
        topBar = {
            Surface(tonalElevation = 2.dp) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(
                            horizontal = 16.dp,
                            vertical = 10.dp
                        ),
                    horizontalArrangement =
                        Arrangement.SpaceBetween,
                    verticalAlignment =
                        Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment =
                            Alignment.CenterVertically
                    ) {
                        Image(
                            painter = painterResource(
                                id = R.drawable.pin_potha_logo
                            ),
                            contentDescription = "Pin Potha",
                            modifier = Modifier.size(42.dp)
                        )

                        Spacer(
                            modifier = Modifier.width(9.dp)
                        )

                        Column {
                            Text(
                                text = tr(
                                    language,
                                    "සැකසුම්",
                                    "Settings"
                                ),
                                fontSize = 23.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Text(
                                text = "by Dinusha Rukshan",
                                fontSize = 11.sp,
                                color =
                                    MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    OutlinedButton(
                        onClick = onBack,
                        modifier = Modifier.height(42.dp),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text(
                            tr(
                                language,
                                "වසන්න",
                                "Close"
                            )
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
                .padding(20.dp),
            verticalArrangement =
                Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(
                        defaultElevation = 1.dp
                    ),
                    colors = CardDefaults.cardColors(
                        containerColor =
                            MaterialTheme.colorScheme.secondaryContainer
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp)
                    ) {
                        SettingsSectionHeader(
                            iconRes = R.drawable.ic_cloud_backup,
                            title = tr(
                                language,
                                "Google උපස්ථය",
                                "Google Backup"
                            ),
                            fontSizeValue = 20
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        if (googleSignedIn) {
                            Text(
                                text = tr(
                                    language,
                                    "Google ගිණුම සම්බන්ධ කර ඇත",
                                    "Google account connected"
                                ),
                                fontWeight = FontWeight.SemiBold
                            )

                            if (googleName.isNotBlank()) {
                                Spacer(
                                    modifier =
                                        Modifier.height(8.dp)
                                )

                                Text(
                                    text = googleName,
                                    fontSize = 16.sp
                                )
                            }

                            if (googleEmail.isNotBlank()) {
                                Text(
                                    text = googleEmail,
                                    fontSize = 14.sp,
                                    color =
                                        MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            }

                            Spacer(modifier = Modifier.height(18.dp))

                            if (driveAccessGranted) {
                                Text(
                                    text = tr(
                                        language,
                                        "✓ Google Drive ප්‍රවේශය සක්‍රීයයි",
                                        "✓ Google Drive access enabled"
                                    ),
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                if (lastBackupAt > 0L) {
                                    Text(
                                        text = tr(
                                            language,
                                            "අවසන් උපස්ථය: ${
                                                formatBackupDateTime(
                                                    lastBackupAt
                                                )
                                            }",
                                            "Last backup: ${
                                                formatBackupDateTime(
                                                    lastBackupAt
                                                )
                                            }"
                                        ),
                                        fontSize = 14.sp
                                    )
                                } else {
                                    Text(
                                        text = tr(
                                            language,
                                            "තවම Google Drive උපස්ථයක් කර නැත.",
                                            "No Google Drive backup has been created yet."
                                        ),
                                        fontSize = 14.sp
                                    )
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Text(
                                    text = tr(
                                        language,
                                        "ස්වයංක්‍රීය උපස්ථය: සක්‍රීයයි",
                                        "Automatic backup: On"
                                    ),
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                Text(
                                    text =
                                        if (autoBackupPending) {
                                            tr(
                                                language,
                                                "වෙනස්කම් Google Drive වෙත උපස්ථ කිරීමට රැඳී සිටී...",
                                                "Changes are waiting to be backed up..."
                                            )
                                        } else {
                                            tr(
                                                language,
                                                "සියලු වෙනස්කම් උපස්ථ කර ඇත.",
                                                "All changes are backed up."
                                            )
                                        },
                                    fontSize = 13.sp
                                )

                                if (autoBackupError != null) {
                                    Spacer(
                                        modifier = Modifier.height(6.dp)
                                    )

                                    Text(
                                        text = autoBackupError,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                Button(
                                    onClick = onBackupNow,
                                    enabled =
                                        !backupInProgress &&
                                                !restoreInProgress &&
                                                !driveAuthorizationLoading,
                                    modifier =
                                        Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text =
                                            if (
                                                backupInProgress ||
                                                driveAuthorizationLoading
                                            ) {
                                                tr(
                                                    language,
                                                    "උපස්ථ කරමින්...",
                                                    "Backing up..."
                                                )
                                            } else {
                                                tr(
                                                    language,
                                                    "දැන් උපස්ථ කරන්න",
                                                    "Backup Now"
                                                )
                                            },
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                if (cloudBackupFound) {
                                    Spacer(
                                        modifier = Modifier.height(10.dp)
                                    )

                                    OutlinedButton(
                                        onClick = {
                                            showRestoreDialog = true
                                        },
                                        enabled =
                                            !backupInProgress &&
                                                    !restoreInProgress &&
                                                    !driveAuthorizationLoading,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text(
                                            text =
                                                if (restoreInProgress) {
                                                    tr(
                                                        language,
                                                        "ප්‍රතිසාධනය කරමින්...",
                                                        "Restoring..."
                                                    )
                                                } else {
                                                    tr(
                                                        language,
                                                        "Google Drive වෙතින් ප්‍රතිසාධනය කරන්න",
                                                        "Restore from Google Drive"
                                                    )
                                                },
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }

                                if (restoreMessage != null) {
                                    Spacer(
                                        modifier = Modifier.height(10.dp)
                                    )

                                    Text(
                                        text = restoreMessage,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }

                                if (restoreError != null) {
                                    Spacer(
                                        modifier = Modifier.height(10.dp)
                                    )

                                    Text(
                                        text = restoreError,
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }

                                if (backupMessage != null) {
                                    Spacer(
                                        modifier =
                                            Modifier.height(10.dp)
                                    )

                                    Text(
                                        text = backupMessage,
                                        fontSize = 14.sp,
                                        fontWeight =
                                            FontWeight.SemiBold
                                    )
                                }

                                if (backupError != null) {
                                    Spacer(
                                        modifier =
                                            Modifier.height(10.dp)
                                    )

                                    Text(
                                        text = backupError,
                                        fontSize = 13.sp,
                                        color =
                                            MaterialTheme.colorScheme.error
                                    )
                                }
                            } else {
                                Text(
                                    text = tr(
                                        language,
                                        "Google Drive අවසරය ලබා දී නැත.",
                                        "Google Drive permission has not been granted yet."
                                    ),
                                    fontSize = 14.sp
                                )

                                Spacer(
                                    modifier =
                                        Modifier.height(14.dp)
                                )

                                Button(
                                    onClick = onEnableDriveBackup,
                                    enabled =
                                        !driveAuthorizationLoading,
                                    modifier =
                                        Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text =
                                            if (
                                                driveAuthorizationLoading
                                            ) {
                                                tr(
                                                    language,
                                                    "Google Drive සම්බන්ධ කරමින්...",
                                                    "Connecting Google Drive..."
                                                )
                                            } else {
                                                tr(
                                                    language,
                                                    "Google Drive උපස්ථය සක්‍රීය කරන්න",
                                                    "Enable Google Drive Backup"
                                                )
                                            }
                                    )
                                }
                            }

                            if (driveAuthorizationError != null) {
                                Spacer(
                                    modifier =
                                        Modifier.height(12.dp)
                                )

                                Text(
                                    text =
                                        driveAuthorizationError,
                                    fontSize = 13.sp,
                                    color =
                                        MaterialTheme.colorScheme.error
                                )
                            }

                            Spacer(modifier = Modifier.height(18.dp))

                            OutlinedButton(
                                onClick = {
                                    showSignOutDialog = true
                                },
                                modifier =
                                    Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    tr(
                                        language,
                                        "Google ගිණුමෙන් ඉවත් වන්න",
                                        "Sign out"
                                    )
                                )
                            }
                        } else {
                            Text(
                                text = tr(
                                    language,
                                    "Google ගිණුමක් සම්බන්ධ කර නැත.",
                                    "No Google account is connected."
                                ),
                                fontSize = 14.sp
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            Button(
                                onClick = onGoogleConnectClick,
                                modifier =
                                    Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    tr(
                                        language,
                                        "Google ගිණුම සම්බන්ධ කරන්න",
                                        "Connect Google Account"
                                    )
                                )
                            }
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(
                        defaultElevation = 1.dp
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp)
                    ) {
                        SettingsSectionHeader(
                            iconRes = R.drawable.ic_print,
                            title = tr(
                                language,
                                "මුද්‍රණය / PDF",
                                "Print / PDF"
                            ),
                            fontSizeValue = 20
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = tr(
                                language,
                                "A4 පිටුවකට තීරු 2ක සරල ආකෘතියකින් පින්කම් මුද්‍රණය කරන්න හෝ PDF ලෙස සුරකින්න.",
                                "Print your good deeds in a compact 2-column A4 layout or save them as a PDF."
                            ),
                            fontSize = 14.sp,
                            color =
                                MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = onPrintExportClick,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                tr(
                                    language,
                                    "මුද්‍රණය / PDF විවෘත කරන්න",
                                    "Open Print / PDF"
                                )
                            )
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(
                        defaultElevation = 1.dp
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp)
                    ) {
                        SettingsSectionHeader(
                            iconRes = R.drawable.ic_person,
                            title = tr(
                                language,
                                "පුද්ගලික තොරතුරු",
                                "Personal Details"
                            ),
                            fontSizeValue = 20
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text =
                                if (hasPersonalDetails) {
                                    tr(
                                        language,
                                        "තොරතුරු සුරකින ලදී",
                                        "Details saved"
                                    )
                                } else {
                                    tr(
                                        language,
                                        "තොරතුරු තවම එක් කර නැත",
                                        "No details added yet"
                                    )
                                },
                            fontSize = 14.sp,
                            color =
                                MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = onPersonalDetailsClick,
                            modifier =
                                Modifier.fillMaxWidth()
                        ) {
                            Text(
                                tr(
                                    language,
                                    "පුද්ගලික තොරතුරු",
                                    "Personal Details"
                                )
                            )
                        }
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(
                        defaultElevation = 1.dp
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp)
                    ) {
                        SettingsSectionHeader(
                            iconRes = R.drawable.ic_language,
                            title = tr(
                                language,
                                "භාෂාව",
                                "Language"
                            ),
                            fontSizeValue = 20
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = tr(
                                language,
                                "යෙදුමේ භාෂාව තෝරන්න.",
                                "Choose the app interface language."
                            ),
                            fontSize = 14.sp,
                            color =
                                MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(18.dp))

                        if (language == AppLanguage.SINHALA) {
                            Button(
                                onClick = {
                                    onLanguageChanged(
                                        AppLanguage.SINHALA
                                    )
                                },
                                modifier =
                                    Modifier.fillMaxWidth()
                            ) {
                                Text("සිංහල ✓")
                            }
                        } else {
                            OutlinedButton(
                                onClick = {
                                    onLanguageChanged(
                                        AppLanguage.SINHALA
                                    )
                                },
                                modifier =
                                    Modifier.fillMaxWidth()
                            ) {
                                Text("සිංහල")
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        if (language == AppLanguage.ENGLISH) {
                            Button(
                                onClick = {
                                    onLanguageChanged(
                                        AppLanguage.ENGLISH
                                    )
                                },
                                modifier =
                                    Modifier.fillMaxWidth()
                            ) {
                                Text("English ✓")
                            }
                        } else {
                            OutlinedButton(
                                onClick = {
                                    onLanguageChanged(
                                        AppLanguage.ENGLISH
                                    )
                                },
                                modifier =
                                    Modifier.fillMaxWidth()
                            ) {
                                Text("English")
                            }
                        }
                    }
                }
            }


            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    elevation = CardDefaults.cardElevation(
                        defaultElevation = 1.dp
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp)
                    ) {
                        SettingsSectionHeader(
                            iconRes = R.drawable.ic_theme,
                            title = tr(
                                language,
                                "පෙනුම",
                                "Appearance"
                            ),
                            fontSizeValue = 20
                        )

                        Spacer(
                            modifier = Modifier.height(6.dp)
                        )

                        Text(
                            text = tr(
                                language,
                                "යෙදුමේ ආලෝක හෝ අඳුරු පෙනුම තෝරන්න.",
                                "Choose the app's light or dark appearance."
                            ),
                            fontSize = 14.sp,
                            color =
                                MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(
                            modifier = Modifier.height(16.dp)
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement =
                                Arrangement.spacedBy(10.dp)
                        ) {
                            if (
                                themeMode ==
                                AppThemeMode.LIGHT
                            ) {
                                Button(
                                    onClick = {
                                        onThemeChanged(
                                            AppThemeMode.LIGHT
                                        )
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(50.dp),
                                    shape =
                                        RoundedCornerShape(14.dp)
                                ) {
                                    Icon(
                                        painter = painterResource(
                                            id =
                                                R.drawable.ic_light_mode
                                        ),
                                        contentDescription = null,
                                        modifier =
                                            Modifier.size(18.dp)
                                    )

                                    Spacer(
                                        modifier =
                                            Modifier.width(6.dp)
                                    )

                                    Text(
                                        tr(
                                            language,
                                            "ආලෝක",
                                            "Light"
                                        )
                                    )
                                }
                            } else {
                                OutlinedButton(
                                    onClick = {
                                        onThemeChanged(
                                            AppThemeMode.LIGHT
                                        )
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(50.dp),
                                    shape =
                                        RoundedCornerShape(14.dp)
                                ) {
                                    Icon(
                                        painter = painterResource(
                                            id =
                                                R.drawable.ic_light_mode
                                        ),
                                        contentDescription = null,
                                        modifier =
                                            Modifier.size(18.dp)
                                    )

                                    Spacer(
                                        modifier =
                                            Modifier.width(6.dp)
                                    )

                                    Text(
                                        tr(
                                            language,
                                            "ආලෝක",
                                            "Light"
                                        )
                                    )
                                }
                            }

                            if (
                                themeMode ==
                                AppThemeMode.DARK
                            ) {
                                Button(
                                    onClick = {
                                        onThemeChanged(
                                            AppThemeMode.DARK
                                        )
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(50.dp),
                                    shape =
                                        RoundedCornerShape(14.dp)
                                ) {
                                    Icon(
                                        painter = painterResource(
                                            id =
                                                R.drawable.ic_dark_mode
                                        ),
                                        contentDescription = null,
                                        modifier =
                                            Modifier.size(18.dp)
                                    )

                                    Spacer(
                                        modifier =
                                            Modifier.width(6.dp)
                                    )

                                    Text(
                                        tr(
                                            language,
                                            "අඳුරු",
                                            "Dark"
                                        )
                                    )
                                }
                            } else {
                                OutlinedButton(
                                    onClick = {
                                        onThemeChanged(
                                            AppThemeMode.DARK
                                        )
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(50.dp),
                                    shape =
                                        RoundedCornerShape(14.dp)
                                ) {
                                    Icon(
                                        painter = painterResource(
                                            id =
                                                R.drawable.ic_dark_mode
                                        ),
                                        contentDescription = null,
                                        modifier =
                                            Modifier.size(18.dp)
                                    )

                                    Spacer(
                                        modifier =
                                            Modifier.width(6.dp)
                                    )

                                    Text(
                                        tr(
                                            language,
                                            "අඳුරු",
                                            "Dark"
                                        )
                                    )
                                }
                            }
                        }

                        Spacer(
                            modifier = Modifier.height(18.dp)
                        )

                        AccentColorPicker(
                            language = language,
                            selectedAccent = accentColor,
                            onAccentSelected =
                                onAccentColorChanged
                        )
                    }
                }
            }

        }
    }


    if (showRestoreDialog) {
        AlertDialog(
            onDismissRequest = {
                showRestoreDialog = false
            },
            title = {
                Text(
                    tr(
                        language,
                        "Google Drive උපස්ථය ප්‍රතිසාධනය කරන්නද?",
                        "Restore Google Drive Backup?"
                    )
                )
            },
            text = {
                Text(
                    tr(
                        language,
                        "Cloud උපස්ථය මෙම දුරකථනයේ දත්ත සමඟ ආරක්ෂිතව ඒකාබද්ධ කරනු ඇත. දුරකථනයේ පවතින පින්කම් මකා නොදමයි. එකම පින්කමක් දෙපැත්තේ තිබේ නම් නවතම අනුවාදය තබා ගනී. පවතින පුද්ගලික තොරතුරු හිස් නම් පමණක් cloud තොරතුරු යොදනු ඇත.",
                        "The cloud backup will be safely merged with this phone. Existing local good deeds will not be deleted. If the same deed exists in both places, the newer version is kept. Cloud personal details are used only where the local field is blank."
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showRestoreDialog = false
                        onRestoreFromDrive()
                    }
                ) {
                    Text(
                        tr(
                            language,
                            "ප්‍රතිසාධනය කරන්න",
                            "Restore"
                        )
                    )
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        showRestoreDialog = false
                    }
                ) {
                    Text(
                        tr(
                            language,
                            "අවලංගු",
                            "Cancel"
                        )
                    )
                }
            }
        )
    }

    if (showSignOutDialog) {
        AlertDialog(
            onDismissRequest = {
                showSignOutDialog = false
            },
            title = {
                Text(
                    tr(
                        language,
                        "Google ගිණුමෙන් ඉවත් වන්නද?",
                        "Sign out of Google?"
                    )
                )
            },
            text = {
                Text(
                    tr(
                        language,
                        "ඔබගේ දුරකථනයේ සුරකින පින්කම් මැකෙන්නේ නැත.",
                        "Your locally saved good deeds will not be deleted."
                    )
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSignOutDialog = false
                        onGoogleSignOut()
                    }
                ) {
                    Text(
                        tr(
                            language,
                            "ඉවත් වන්න",
                            "Sign out"
                        )
                    )
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = {
                        showSignOutDialog = false
                    }
                ) {
                    Text(
                        tr(
                            language,
                            "අවලංගු",
                            "Cancel"
                        )
                    )
                }
            }
        )
    }
}

@Composable
fun PrintExportScreen(
    language: AppLanguage,
    goodDeedCount: Int,
    hasPersonalDetails: Boolean,
    isWorking: Boolean,
    message: String?,
    error: String?,
    onPrintPreview: () -> Unit,
    onSavePdf: () -> Unit,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            Surface(tonalElevation = 2.dp) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(
                            start = 20.dp,
                            end = 20.dp,
                            top = 10.dp,
                            bottom = 14.dp
                        )
                ) {
                    Text(
                        text = tr(
                            language,
                            "මුද්‍රණය / PDF",
                            "Print / PDF"
                        ),
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = "by Dinusha Rukshan",
                        fontSize = 12.sp,
                        color =
                            MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
                .padding(20.dp),
            verticalArrangement =
                Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor =
                            MaterialTheme.colorScheme.secondaryContainer
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp)
                    ) {
                        Text(
                            text = tr(
                                language,
                                "A4 මුද්‍රණ ආකෘතිය",
                                "A4 Print Layout"
                            ),
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = tr(
                                language,
                                "• A4 Portrait\n• තීරු 2ක compact layout\n• පින්කම් ${goodDeedCount}\n• හිස් පුද්ගලික තොරතුරු PDF එකට ඇතුළත් නොවේ",
                                "• A4 Portrait\n• Compact 2-column layout\n• $goodDeedCount good deeds\n• Blank personal-detail fields are omitted"
                            ),
                            fontSize = 15.sp,
                            lineHeight = 23.sp
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text =
                                if (hasPersonalDetails) {
                                    tr(
                                        language,
                                        "සුරකින ලද පුද්ගලික තොරතුරු පළමු පිටුවේ ඉහළින් ඇතුළත් වේ.",
                                        "Saved personal details will appear compactly at the top of the first page."
                                    )
                                } else {
                                    tr(
                                        language,
                                        "පුද්ගලික තොරතුරු නොමැති නිසා පින්කම් පළමු පිටුවේ සිටම ආරම්භ වේ.",
                                        "No personal details are saved, so the good deeds begin immediately on the first page."
                                    )
                                },
                            fontSize = 14.sp,
                            color =
                                MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            item {
                Button(
                    onClick = onPrintPreview,
                    enabled = !isWorking,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text =
                            if (isWorking) {
                                tr(
                                    language,
                                    "PDF සකසමින්...",
                                    "Preparing PDF..."
                                )
                            } else {
                                tr(
                                    language,
                                    "මුද්‍රණ පෙරදසුන",
                                    "Print / Preview"
                                )
                            },
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            item {
                OutlinedButton(
                    onClick = onSavePdf,
                    enabled = !isWorking,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = tr(
                            language,
                            "PDF ලෙස සුරකින්න",
                            "Save PDF"
                        ),
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            if (message != null) {
                item {
                    Text(
                        text = message,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            if (error != null) {
                item {
                    Text(
                        text = error,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }

            item {
                Text(
                    text = tr(
                        language,
                        "Print / Preview ඔබගේ Android මුද්‍රණ තිරය විවෘත කරයි. එහිදී මුද්‍රණයට පෙර PDF පෙරදසුන දැකිය හැක.",
                        "Print / Preview opens Android's print screen, where you can inspect the PDF before printing."
                    ),
                    fontSize = 13.sp,
                    color =
                        MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            item {
                OutlinedButton(
                    onClick = onBack,
                    enabled = !isWorking,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                ) {
                    Text(
                        text = tr(
                            language,
                            "ආපසු",
                            "Back"
                        ),
                        fontSize = 16.sp
                    )
                }
            }
        }
    }
}

@Composable
fun PersonalDetailsScreen(
    language: AppLanguage,
    initialName: String,
    initialPhone: String,
    initialAddress: String,
    initialNic: String,
    onSave: (
        String,
        String,
        String,
        String
    ) -> Unit,
    onBack: () -> Unit
) {
    var name by remember(initialName) {
        mutableStateOf(initialName)
    }

    var phone by remember(initialPhone) {
        mutableStateOf(initialPhone)
    }

    var address by remember(initialAddress) {
        mutableStateOf(initialAddress)
    }

    var nic by remember(initialNic) {
        mutableStateOf(initialNic)
    }

    Scaffold(
        topBar = {
            Surface(tonalElevation = 2.dp) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text = tr(
                            language,
                            "පුද්ගලික තොරතුරු",
                            "Personal Details"
                        ),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = "by Dinusha Rukshan",
                        fontSize = 12.sp,
                        color =
                            MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .navigationBarsPadding()
                .padding(20.dp),
            verticalArrangement =
                Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor =
                            MaterialTheme.colorScheme.secondaryContainer
                    )
                ) {
                    Text(
                        text = tr(
                            language,
                            "මෙම තොරතුරු එක් කිරීම අත්‍යවශ්‍ය නොවේ. ඔබට අවශ්‍ය තොරතුරු පමණක් එක් කළ හැක. පසුව මුද්‍රණය කරන පින් පොතේ පළමු පිටුවට මෙම තොරතුරු භාවිතා කළ හැක.",
                            "These details are optional. Add only the information you want. They can later be used on the first page of your printed Pin Potha."
                        ),
                        modifier = Modifier.padding(16.dp),
                        fontSize = 15.sp,
                        lineHeight = 22.sp
                    )
                }
            }

            item {
                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = {
                        Text(
                            tr(
                                language,
                                "නම",
                                "Name"
                            )
                        )
                    },
                    shape = RoundedCornerShape(16.dp)
                )
            }

            item {
                OutlinedTextField(
                    value = phone,
                    onValueChange = {
                        phone = it
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Phone
                    ),
                    label = {
                        Text(
                            tr(
                                language,
                                "දුරකථන අංකය",
                                "Phone Number"
                            )
                        )
                    },
                    shape = RoundedCornerShape(16.dp)
                )
            }

            item {
                OutlinedTextField(
                    value = address,
                    onValueChange = {
                        address = it
                    },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                    maxLines = 5,
                    label = {
                        Text(
                            tr(
                                language,
                                "ලිපිනය",
                                "Address"
                            )
                        )
                    },
                    shape = RoundedCornerShape(16.dp)
                )
            }

            item {
                OutlinedTextField(
                    value = nic,
                    onValueChange = {
                        nic = it
                    },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = {
                        Text(
                            tr(
                                language,
                                "ජාතික හැඳුනුම්පත් අංකය",
                                "NIC Number"
                            )
                        )
                    },
                    shape = RoundedCornerShape(16.dp)
                )
            }

            item {
                Spacer(modifier = Modifier.height(4.dp))

                Button(
                    onClick = {
                        onSave(
                            name,
                            phone,
                            address,
                            nic
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(62.dp),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Text(
                        text = tr(
                            language,
                            "තොරතුරු සුරකින්න",
                            "Save Details"
                        ),
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            item {
                OutlinedButton(
                    onClick = onBack,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                ) {
                    Text(
                        text = tr(
                            language,
                            "ආපසු",
                            "Back"
                        ),
                        fontSize = 16.sp
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }
}
