package com.dinusharukshan.pinpotha

import android.content.Context
import android.content.SharedPreferences
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

object AutoBackupScheduler {

    const val PREF_CHANGE_VERSION =
        "auto_backup_change_version"

    const val PREF_LAST_BACKED_UP_VERSION =
        "auto_backup_last_backed_up_version"

    const val PREF_AUTO_BACKUP_ERROR =
        "auto_backup_error"

    const val PREF_AUTO_BACKUP_NEEDS_CONSENT =
        "auto_backup_needs_consent"

    private const val UNIQUE_WORK_NAME =
        "pin_potha_auto_backup"

    private const val PREFERENCES_NAME =
        "pin_potha_preferences"

    private fun preferences(context: Context): SharedPreferences =
        context.getSharedPreferences(
            PREFERENCES_NAME,
            Context.MODE_PRIVATE
        )

    fun isBackupPending(
        preferences: SharedPreferences
    ): Boolean {
        val currentVersion =
            preferences.getLong(
                PREF_CHANGE_VERSION,
                0L
            )

        val backedUpVersion =
            preferences.getLong(
                PREF_LAST_BACKED_UP_VERSION,
                0L
            )

        return currentVersion > backedUpVersion
    }

    @Synchronized
    fun markChangedAndSchedule(
        context: Context
    ) {
        val appContext =
            context.applicationContext

        val prefs =
            preferences(appContext)

        val nextVersion =
            prefs.getLong(
                PREF_CHANGE_VERSION,
                0L
            ) + 1L

        prefs.edit()
            .putLong(
                PREF_CHANGE_VERSION,
                nextVersion
            )
            .remove(PREF_AUTO_BACKUP_ERROR)
            .apply()

        scheduleIfNeeded(
            appContext
        )
    }

    fun scheduleIfNeeded(
        context: Context
    ) {
        val appContext =
            context.applicationContext

        val prefs =
            preferences(appContext)

        if (!isBackupPending(prefs)) {
            return
        }

        val googleSignedIn =
            prefs.getBoolean(
                "google_signed_in",
                false
            )

        val driveAccessGranted =
            prefs.getBoolean(
                "drive_access_granted",
                false
            )

        if (
            !googleSignedIn ||
            !driveAccessGranted
        ) {
            return
        }

        val constraints =
            Constraints.Builder()
                .setRequiredNetworkType(
                    NetworkType.CONNECTED
                )
                .build()

        val request =
            OneTimeWorkRequestBuilder<AutoBackupWorker>()
                .setConstraints(constraints)
                .setInitialDelay(
                    3,
                    TimeUnit.SECONDS
                )
                .setBackoffCriteria(
                    BackoffPolicy.EXPONENTIAL,
                    10,
                    TimeUnit.SECONDS
                )
                .addTag(UNIQUE_WORK_NAME)
                .build()

        WorkManager
            .getInstance(appContext)
            .enqueueUniqueWork(
                UNIQUE_WORK_NAME,
                ExistingWorkPolicy.KEEP,
                request
            )
    }

    fun markBackupCompleted(
        context: Context,
        backedUpAt: Long
    ) {
        val prefs =
            preferences(
                context.applicationContext
            )

        val currentVersion =
            prefs.getLong(
                PREF_CHANGE_VERSION,
                0L
            )

        prefs.edit()
            .putLong(
                PREF_LAST_BACKED_UP_VERSION,
                currentVersion
            )
            .putLong(
                "last_backup_at",
                backedUpAt
            )
            .remove(PREF_AUTO_BACKUP_ERROR)
            .remove(PREF_AUTO_BACKUP_NEEDS_CONSENT)
            .apply()
    }

    fun cancelScheduledWork(
        context: Context
    ) {
        WorkManager
            .getInstance(
                context.applicationContext
            )
            .cancelUniqueWork(
                UNIQUE_WORK_NAME
            )
    }
}
