package com.dinusharukshan.pinpotha

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

class AutoBackupWorker(
    appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(
    appContext,
    workerParams
) {

    companion object {
        private const val PREFERENCES_NAME =
            "pin_potha_preferences"
    }

    override suspend fun doWork(): Result {
        val preferences =
            applicationContext.getSharedPreferences(
                PREFERENCES_NAME,
                Context.MODE_PRIVATE
            )

        val googleSignedIn =
            preferences.getBoolean(
                "google_signed_in",
                false
            )

        val driveAccessGranted =
            preferences.getBoolean(
                "drive_access_granted",
                false
            )

        if (
            !googleSignedIn ||
            !driveAccessGranted
        ) {
            return Result.success()
        }

        val changeVersionAtStart =
            preferences.getLong(
                AutoBackupScheduler.PREF_CHANGE_VERSION,
                0L
            )

        val lastBackedUpVersion =
            preferences.getLong(
                AutoBackupScheduler.PREF_LAST_BACKED_UP_VERSION,
                0L
            )

        if (
            changeVersionAtStart <=
            lastBackedUpVersion
        ) {
            return Result.success()
        }

        val driveManager =
            GoogleDriveBackupManager(
                applicationContext
            )

        val authorizationState =
            requestAuthorization(
                driveManager
            )

        return when (authorizationState) {

            is DriveAuthorizationState.Authorized -> {
                preferences.edit()
                    .putBoolean(
                        "drive_access_granted",
                        true
                    )
                    .remove(
                        AutoBackupScheduler.PREF_AUTO_BACKUP_NEEDS_CONSENT
                    )
                    .apply()

                val database =
                    PinPothaDatabase.getDatabase(
                        applicationContext
                    )

                val goodDeeds =
                    database.goodDeedDao()
                        .getAllGoodDeedsOnce()

                val backupJson =
                    driveManager.createBackupJson(
                        profileName =
                            preferences.getString(
                                "profile_name",
                                ""
                            ) ?: "",
                        profilePhone =
                            preferences.getString(
                                "profile_phone",
                                ""
                            ) ?: "",
                        profileAddress =
                            preferences.getString(
                                "profile_address",
                                ""
                            ) ?: "",
                        profileNic =
                            preferences.getString(
                                "profile_nic",
                                ""
                            ) ?: "",
                        goodDeeds = goodDeeds
                    )

                when (
                    val backupResult =
                        driveManager.backupJsonToDrive(
                            accessToken =
                                authorizationState.accessToken,
                            backupJson =
                                backupJson
                        )
                ) {

                    is DriveBackupResult.Success -> {
                        preferences.edit()
                            .putLong(
                                "last_backup_at",
                                backupResult.backedUpAt
                            )
                            .putLong(
                                AutoBackupScheduler.PREF_LAST_BACKED_UP_VERSION,
                                changeVersionAtStart
                            )
                            .remove(
                                AutoBackupScheduler.PREF_AUTO_BACKUP_ERROR
                            )
                            .remove(
                                AutoBackupScheduler.PREF_AUTO_BACKUP_NEEDS_CONSENT
                            )
                            .apply()

                        val newestChangeVersion =
                            preferences.getLong(
                                AutoBackupScheduler.PREF_CHANGE_VERSION,
                                0L
                            )

                        if (
                            newestChangeVersion >
                            changeVersionAtStart
                        ) {
                            Result.retry()
                        } else {
                            Result.success()
                        }
                    }

                    is DriveBackupResult.Error -> {
                        saveError(
                            preferences,
                            backupResult.message
                        )

                        retryOrStop()
                    }
                }
            }

            is DriveAuthorizationState.NeedsUserConsent -> {
                preferences.edit()
                    .putBoolean(
                        AutoBackupScheduler.PREF_AUTO_BACKUP_NEEDS_CONSENT,
                        true
                    )
                    .putBoolean(
                        "drive_access_granted",
                        false
                    )
                    .putString(
                        AutoBackupScheduler.PREF_AUTO_BACKUP_ERROR,
                        "Open Pin Potha and enable Google Drive access again."
                    )
                    .apply()

                Result.success()
            }

            is DriveAuthorizationState.Error -> {
                saveError(
                    preferences,
                    authorizationState.message
                )

                retryOrStop()
            }
        }
    }

    private suspend fun requestAuthorization(
        manager: GoogleDriveBackupManager
    ): DriveAuthorizationState =
        suspendCancellableCoroutine { continuation ->
            manager.requestDriveAuthorization { state ->
                if (continuation.isActive) {
                    continuation.resume(state)
                }
            }
        }

    private fun saveError(
        preferences: android.content.SharedPreferences,
        message: String
    ) {
        preferences.edit()
            .putString(
                AutoBackupScheduler.PREF_AUTO_BACKUP_ERROR,
                message
            )
            .apply()
    }

    private fun retryOrStop(): Result =
        if (runAttemptCount < 5) {
            Result.retry()
        } else {
            Result.success()
        }
}
