package com.dinusharukshan.pinpotha

import android.app.Activity
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.print.PageRange
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.io.File
import java.io.FileOutputStream
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class PinPothaPdfManager(
    private val activity: Activity
) {

    companion object {
        private const val PAGE_WIDTH = 595
        private const val PAGE_HEIGHT = 842

        private const val LEFT_MARGIN = 28f
        private const val RIGHT_MARGIN = 28f
        private const val TOP_MARGIN = 26f
        private const val BOTTOM_MARGIN = 28f
        private const val COLUMN_GAP = 14f

        private const val BODY_TEXT_SIZE = 10.8f
        private const val DATE_TEXT_SIZE = 9.0f
        private const val PROFILE_TEXT_SIZE = 9.4f
    }

    fun createPdfFile(
        language: AppLanguage,
        profileName: String,
        profilePhone: String,
        profileAddress: String,
        profileNic: String,
        goodDeeds: List<GoodDeedEntity>
    ): File {
        val exportDir = File(
            activity.cacheDir,
            "pin_potha_exports"
        )

        if (!exportDir.exists()) {
            exportDir.mkdirs()
        }

        val fileName =
            "Pin_Potha_${
                DateTimeFormatter.ofPattern("yyyy-MM-dd_HHmmss")
                    .format(
                        java.time.LocalDateTime.now()
                    )
            }.pdf"

        val outputFile = File(
            exportDir,
            fileName
        )

        val document = PdfDocument()

        try {
            renderDocument(
                document = document,
                language = language,
                profileName = profileName,
                profilePhone = profilePhone,
                profileAddress = profileAddress,
                profileNic = profileNic,
                goodDeeds = goodDeeds
            )

            FileOutputStream(outputFile).use { output ->
                document.writeTo(output)
            }
        } finally {
            document.close()
        }

        return outputFile
    }

    fun savePdfToUri(
        sourceFile: File,
        destinationUri: Uri
    ) {
        val output =
            activity.contentResolver
                .openOutputStream(destinationUri)
                ?: throw IllegalStateException(
                    "Could not open the selected PDF destination."
                )

        output.use { destination ->
            sourceFile.inputStream().use { source ->
                source.copyTo(destination)
            }
        }
    }

    fun printPdf(
        pdfFile: File,
        language: AppLanguage
    ) {
        val printManager =
            activity.getSystemService(
                Context.PRINT_SERVICE
            ) as PrintManager

        val jobName =
            tr(
                language,
                "පින් පොත",
                "Pin Potha"
            )

        val attributes =
            PrintAttributes.Builder()
                .setMediaSize(
                    PrintAttributes.MediaSize.ISO_A4
                )
                .setColorMode(
                    PrintAttributes.COLOR_MODE_MONOCHROME
                )
                .build()

        printManager.print(
            jobName,
            PdfFilePrintAdapter(pdfFile),
            attributes
        )
    }

    private fun renderDocument(
        document: PdfDocument,
        language: AppLanguage,
        profileName: String,
        profilePhone: String,
        profileAddress: String,
        profileNic: String,
        goodDeeds: List<GoodDeedEntity>
    ) {
        val columnWidth =
            (PAGE_WIDTH -
                    LEFT_MARGIN -
                    RIGHT_MARGIN -
                    COLUMN_GAP) / 2f

        val columnLeft =
            floatArrayOf(
                LEFT_MARGIN,
                LEFT_MARGIN + columnWidth + COLUMN_GAP
            )

        val bodyBottom =
            PAGE_HEIGHT - BOTTOM_MARGIN - 12f

        val titlePaint =
            TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.BLACK
                textSize = 18f
                typeface =
                    Typeface.create(
                        "sans-serif",
                        Typeface.BOLD
                    )
            }

        val bylinePaint =
            TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.DKGRAY
                textSize = 8.5f
                typeface =
                    Typeface.create(
                        "sans-serif",
                        Typeface.NORMAL
                    )
            }

        val profilePaint =
            TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(35, 35, 35)
                textSize = PROFILE_TEXT_SIZE
                typeface =
                    Typeface.create(
                        "sans-serif",
                        Typeface.NORMAL
                    )
            }

        val datePaint =
            TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(60, 60, 60)
                textSize = DATE_TEXT_SIZE
                typeface =
                    Typeface.create(
                        "sans-serif",
                        Typeface.BOLD
                    )
            }

        val bodyPaint =
            TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.BLACK
                textSize = BODY_TEXT_SIZE
                typeface =
                    Typeface.create(
                        "sans-serif",
                        Typeface.NORMAL
                    )
            }

        val smallPaint =
            TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.DKGRAY
                textSize = 8f
                typeface =
                    Typeface.create(
                        "sans-serif",
                        Typeface.NORMAL
                    )
            }

        val dividerPaint =
            Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.rgb(224, 224, 224)
                strokeWidth = 0.55f
            }

        var pageNumber = 0
        var page: PdfDocument.Page? = null
        var columnIndex = 0
        var currentY = 0f
        var pageBodyTop = TOP_MARGIN

        fun drawCenteredText(
            canvas: android.graphics.Canvas,
            text: String,
            paint: TextPaint,
            y: Float
        ) {
            val width = paint.measureText(text)
            canvas.drawText(
                text,
                (PAGE_WIDTH - width) / 2f,
                y,
                paint
            )
        }

        fun drawFooter(
            currentPage: PdfDocument.Page,
            number: Int
        ) {
            val footer =
                tr(
                    language,
                    "පිටුව $number",
                    "Page $number"
                )

            drawCenteredText(
                currentPage.canvas,
                footer,
                smallPaint,
                PAGE_HEIGHT - 12f
            )
        }

        fun drawFirstPageHeader(
            currentPage: PdfDocument.Page
        ): Float {
            val canvas = currentPage.canvas
            var y = TOP_MARGIN + 16f

            val logoBitmap =
                BitmapFactory.decodeResource(
                    activity.resources,
                    R.drawable.pin_potha_logo
                )

            if (logoBitmap != null) {
                val logoSize = 27f

                canvas.drawBitmap(
                    logoBitmap,
                    null,
                    RectF(
                        LEFT_MARGIN,
                        TOP_MARGIN,
                        LEFT_MARGIN + logoSize,
                        TOP_MARGIN + logoSize
                    ),
                    Paint(Paint.ANTI_ALIAS_FLAG)
                )
            }

            drawCenteredText(
                canvas,
                tr(
                    language,
                    "පින් පොත",
                    "Pin Potha"
                ),
                titlePaint,
                y
            )

            y += 14f

            drawCenteredText(
                canvas,
                "by Dinusha Rukshan",
                bylinePaint,
                y
            )

            y += 14f

            val totalText =
                tr(
                    language,
                    "සටහන් කළ පින්කම්: ${goodDeeds.size}",
                    "Recorded good deeds: ${goodDeeds.size}"
                )

            drawCenteredText(
                canvas,
                totalText,
                smallPaint,
                y
            )

            y += 11f

            val profileParts =
                buildList {
                    if (profileName.isNotBlank()) {
                        add(
                            tr(
                                language,
                                "නම: ${profileName.trim()}",
                                "Name: ${profileName.trim()}"
                            )
                        )
                    }

                    if (profilePhone.isNotBlank()) {
                        add(
                            tr(
                                language,
                                "දුරකථන: ${profilePhone.trim()}",
                                "Phone: ${profilePhone.trim()}"
                            )
                        )
                    }

                    if (profileNic.isNotBlank()) {
                        add(
                            "NIC: ${profileNic.trim()}"
                        )
                    }

                    if (profileAddress.isNotBlank()) {
                        add(
                            tr(
                                language,
                                "ලිපිනය: ${profileAddress.trim()}",
                                "Address: ${profileAddress.trim()}"
                            )
                        )
                    }
                }

            if (profileParts.isNotEmpty()) {
                val profileText =
                    profileParts.joinToString("   •   ")

                val profileLayout =
                    buildLayout(
                        text = profileText,
                        paint = profilePaint,
                        width = (
                                PAGE_WIDTH -
                                        LEFT_MARGIN -
                                        RIGHT_MARGIN
                                ).toInt(),
                        lineSpacingMultiplier = 1.08f
                    )

                drawLayout(
                    canvas = canvas,
                    layout = profileLayout,
                    left = LEFT_MARGIN,
                    top = y
                )

                y += profileLayout.height + 8f
            }

            canvas.drawLine(
                LEFT_MARGIN,
                y,
                PAGE_WIDTH - RIGHT_MARGIN,
                y,
                dividerPaint
            )

            return y + 10f
        }

        fun startPage() {
            pageNumber++

            val pageInfo =
                PdfDocument.PageInfo.Builder(
                    PAGE_WIDTH,
                    PAGE_HEIGHT,
                    pageNumber
                ).create()

            page = document.startPage(pageInfo)
            columnIndex = 0

            pageBodyTop =
                if (pageNumber == 1) {
                    drawFirstPageHeader(page!!)
                } else {
                    TOP_MARGIN
                }

            currentY = pageBodyTop
        }

        fun finishCurrentPage() {
            val currentPage = page ?: return
            drawFooter(currentPage, pageNumber)
            document.finishPage(currentPage)
            page = null
        }

        fun moveToNextColumnOrPage() {
            if (columnIndex == 0) {
                columnIndex = 1
                currentY = pageBodyTop
            } else {
                finishCurrentPage()
                startPage()
            }
        }

        fun availableHeight(): Float =
            bodyBottom - currentY

        fun currentLeft(): Float =
            columnLeft[columnIndex]

        fun drawSeparator() {
            page!!.canvas.drawLine(
                currentLeft(),
                currentY,
                currentLeft() + columnWidth,
                currentY,
                dividerPaint
            )

            currentY += 8f
        }

        fun drawDeed(
            dateText: String,
            description: String
        ) {
            var remaining = description.trim()
            var firstFragment = true

            while (remaining.isNotEmpty()) {
                val dateLayout =
                    if (firstFragment) {
                        buildLayout(
                            text = dateText,
                            paint = datePaint,
                            width = columnWidth.toInt(),
                            lineSpacingMultiplier = 1f
                        )
                    } else {
                        null
                    }

                val dateHeight =
                    if (dateLayout != null) {
                        dateLayout.height + 3f
                    } else {
                        0f
                    }

                val minimumNeeded =
                    dateHeight + BODY_TEXT_SIZE * 2.2f + 10f

                if (availableHeight() < minimumNeeded) {
                    moveToNextColumnOrPage()
                    continue
                }

                if (dateLayout != null) {
                    drawLayout(
                        canvas = page!!.canvas,
                        layout = dateLayout,
                        left = currentLeft(),
                        top = currentY
                    )

                    currentY += dateHeight
                }

                val maxDescriptionHeight =
                    (availableHeight() - 10f)
                        .coerceAtLeast(BODY_TEXT_SIZE * 1.5f)

                val fullLayout =
                    buildLayout(
                        text = remaining,
                        paint = bodyPaint,
                        width = columnWidth.toInt(),
                        lineSpacingMultiplier = 1.08f
                    )

                if (fullLayout.height <= maxDescriptionHeight) {
                    drawLayout(
                        canvas = page!!.canvas,
                        layout = fullLayout,
                        left = currentLeft(),
                        top = currentY
                    )

                    currentY += fullLayout.height + 7f
                    remaining = ""
                    drawSeparator()
                } else {
                    var fittingLines = 0

                    for (line in 0 until fullLayout.lineCount) {
                        if (
                            fullLayout.getLineBottom(line) <=
                            maxDescriptionHeight
                        ) {
                            fittingLines = line + 1
                        } else {
                            break
                        }
                    }

                    if (fittingLines <= 0) {
                        moveToNextColumnOrPage()
                        continue
                    }

                    val endIndex =
                        fullLayout.getLineEnd(
                            fittingLines - 1
                        )

                    val fragment =
                        remaining
                            .substring(0, endIndex)
                            .trimEnd()

                    val fragmentLayout =
                        buildLayout(
                            text = fragment,
                            paint = bodyPaint,
                            width = columnWidth.toInt(),
                            lineSpacingMultiplier = 1.08f
                        )

                    drawLayout(
                        canvas = page!!.canvas,
                        layout = fragmentLayout,
                        left = currentLeft(),
                        top = currentY
                    )

                    currentY += fragmentLayout.height + 4f

                    remaining =
                        remaining
                            .substring(endIndex)
                            .trimStart()

                    moveToNextColumnOrPage()
                }

                firstFragment = false
            }
        }

        startPage()

        if (goodDeeds.isEmpty()) {
            val emptyLayout =
                buildLayout(
                    text = tr(
                        language,
                        "තවම පින්කම් සටහන් කර නැත.",
                        "No good deeds have been recorded yet."
                    ),
                    paint = bodyPaint,
                    width = columnWidth.toInt(),
                    lineSpacingMultiplier = 1.08f
                )

            drawLayout(
                canvas = page!!.canvas,
                layout = emptyLayout,
                left = currentLeft(),
                top = currentY
            )
        } else {
            val dateFormatter =
                DateTimeFormatter.ofPattern(
                    "dd MMM yyyy • hh:mm a"
                )

            goodDeeds.forEach { deed ->
                val dateText =
                    Instant.ofEpochMilli(
                        deed.deedDateTime
                    )
                        .atZone(ZoneId.systemDefault())
                        .format(dateFormatter)

                drawDeed(
                    dateText = dateText,
                    description = deed.description
                )
            }
        }

        finishCurrentPage()
    }

    private fun buildLayout(
        text: String,
        paint: TextPaint,
        width: Int,
        lineSpacingMultiplier: Float
    ): StaticLayout {
        return StaticLayout.Builder
            .obtain(
                text,
                0,
                text.length,
                paint,
                width.coerceAtLeast(1)
            )
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setIncludePad(false)
            .setLineSpacing(
                0f,
                lineSpacingMultiplier
            )
            .build()
    }

    private fun drawLayout(
        canvas: android.graphics.Canvas,
        layout: StaticLayout,
        left: Float,
        top: Float
    ) {
        canvas.save()
        canvas.translate(left, top)
        layout.draw(canvas)
        canvas.restore()
    }

    private class PdfFilePrintAdapter(
        private val pdfFile: File
    ) : PrintDocumentAdapter() {

        override fun onLayout(
            oldAttributes: PrintAttributes?,
            newAttributes: PrintAttributes?,
            cancellationSignal: CancellationSignal?,
            callback: LayoutResultCallback?,
            extras: android.os.Bundle?
        ) {
            if (cancellationSignal?.isCanceled == true) {
                callback?.onLayoutCancelled()
                return
            }

            val info =
                PrintDocumentInfo.Builder(
                    pdfFile.name
                )
                    .setContentType(
                        PrintDocumentInfo.CONTENT_TYPE_DOCUMENT
                    )
                    .setPageCount(
                        PrintDocumentInfo.PAGE_COUNT_UNKNOWN
                    )
                    .build()

            callback?.onLayoutFinished(
                info,
                true
            )
        }

        override fun onWrite(
            pages: Array<out PageRange>?,
            destination: ParcelFileDescriptor?,
            cancellationSignal: CancellationSignal?,
            callback: WriteResultCallback?
        ) {
            if (destination == null) {
                callback?.onWriteFailed(
                    "No print destination was provided."
                )
                return
            }

            try {
                pdfFile.inputStream().use { input ->
                    FileOutputStream(
                        destination.fileDescriptor
                    ).use { output ->
                        val buffer = ByteArray(16 * 1024)

                        while (true) {
                            if (
                                cancellationSignal?.isCanceled ==
                                true
                            ) {
                                callback?.onWriteCancelled()
                                return
                            }

                            val count = input.read(buffer)
                            if (count <= 0) break
                            output.write(buffer, 0, count)
                        }
                    }
                }

                callback?.onWriteFinished(
                    arrayOf(PageRange.ALL_PAGES)
                )
            } catch (exception: Exception) {
                callback?.onWriteFailed(
                    exception.localizedMessage
                        ?: "Could not prepare the PDF for printing."
                )
            }
        }
    }
}
