plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

android {

    namespace = "com.dinusharukshan.pinpotha"

    compileSdk {
        version = release(37)
    }

    defaultConfig {

        applicationId = "com.dinusharukshan.pinpotha"

        minSdk = 26
        targetSdk = 37

        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner =
            "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {

        release {

            isMinifyEnabled = false

            proguardFiles(
                getDefaultProguardFile(
                    "proguard-android-optimize.txt"
                ),
                "proguard-rules.pro"
            )
        }
    }

    buildFeatures {
        compose = true
    }
}


dependencies {

    // ========================================================
    // ANDROID
    // ========================================================

    implementation(
        libs.androidx.core.ktx
    )

    implementation(
        libs.androidx.lifecycle.runtime.ktx
    )

    implementation(
        libs.androidx.activity.compose
    )


    // ========================================================
    // COMPOSE
    // ========================================================

    implementation(
        platform(
            libs.androidx.compose.bom
        )
    )

    implementation(
        libs.androidx.compose.ui
    )

    implementation(
        libs.androidx.compose.ui.graphics
    )

    implementation(
        libs.androidx.compose.ui.tooling.preview
    )

    implementation(
        libs.androidx.compose.material3
    )


    // ========================================================
    // ROOM DATABASE
    // ========================================================

    implementation(
        libs.androidx.room.runtime
    )

    implementation(
        libs.androidx.room.ktx
    )

    ksp(
        libs.androidx.room.compiler
    )


    // ========================================================
    // GOOGLE SIGN-IN
    // ========================================================

    implementation(
        libs.androidx.credentials
    )

    implementation(
        libs.androidx.credentials.play.services.auth
    )

    implementation(
        libs.googleid
    )


    // ========================================================
    // GOOGLE AUTHORIZATION / DRIVE
    // ========================================================

    implementation(
        libs.google.play.services.auth
    )


    // ========================================================
    // WORKMANAGER - AUTOMATIC BACKUP
    // ========================================================

    implementation(
        "androidx.work:work-runtime-ktx:2.11.2"
    )


    // ========================================================
    // TESTS
    // ========================================================

    testImplementation(
        libs.junit
    )

    androidTestImplementation(
        libs.androidx.junit
    )

    androidTestImplementation(
        libs.androidx.espresso.core
    )

    androidTestImplementation(
        platform(
            libs.androidx.compose.bom
        )
    )

    androidTestImplementation(
        libs.androidx.compose.ui.test.junit4
    )

    debugImplementation(
        libs.androidx.compose.ui.tooling
    )

    debugImplementation(
        libs.androidx.compose.ui.test.manifest
    )
}