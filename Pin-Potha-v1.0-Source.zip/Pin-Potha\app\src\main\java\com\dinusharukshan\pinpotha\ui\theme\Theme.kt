package com.dinusharukshan.pinpotha.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

enum class PinPothaAccent {
    PURPLE,
    BLUE,
    TEAL,
    ROSE,
    ORANGE
}

fun accentPreviewColor(
    accent: PinPothaAccent
): Color =
    when (accent) {
        PinPothaAccent.PURPLE ->
            Color(0xFF6750A4)

        PinPothaAccent.BLUE ->
            Color(0xFF0061A4)

        PinPothaAccent.TEAL ->
            Color(0xFF006B5E)

        PinPothaAccent.ROSE ->
            Color(0xFFA33B63)

        PinPothaAccent.ORANGE ->
            Color(0xFF8B5000)
    }


private fun lightScheme(
    accent: PinPothaAccent
): ColorScheme =
    when (accent) {

        PinPothaAccent.PURPLE ->
            lightColorScheme(
                primary = Color(0xFF6750A4),
                onPrimary = Color.White,
                primaryContainer = Color(0xFFEADDFF),
                onPrimaryContainer = Color(0xFF21005D),

                secondary = Color(0xFF625B71),
                onSecondary = Color.White,
                secondaryContainer = Color(0xFFE8DEF8),
                onSecondaryContainer = Color(0xFF1D192B),

                tertiary = Color(0xFF7D5260),
                onTertiary = Color.White,
                tertiaryContainer = Color(0xFFFFD8E4),
                onTertiaryContainer = Color(0xFF31111D),

                background = Color(0xFFFFFBFE),
                onBackground = Color(0xFF1C1B1F),

                surface = Color(0xFFFFFBFE),
                onSurface = Color(0xFF1C1B1F),
                surfaceVariant = Color(0xFFE7E0EC),
                onSurfaceVariant = Color(0xFF49454F),

                outline = Color(0xFF79747E),
                error = Color(0xFFB3261E),
                onError = Color.White
            )

        PinPothaAccent.BLUE ->
            lightColorScheme(
                primary = Color(0xFF0061A4),
                onPrimary = Color.White,
                primaryContainer = Color(0xFFD1E4FF),
                onPrimaryContainer = Color(0xFF001D36),

                secondary = Color(0xFF535F70),
                onSecondary = Color.White,
                secondaryContainer = Color(0xFFD7E3F7),
                onSecondaryContainer = Color(0xFF101C2B),

                tertiary = Color(0xFF6B5778),
                onTertiary = Color.White,
                tertiaryContainer = Color(0xFFF2DAFF),
                onTertiaryContainer = Color(0xFF251431),

                background = Color(0xFFFDFCFF),
                onBackground = Color(0xFF1A1C1E),

                surface = Color(0xFFFDFCFF),
                onSurface = Color(0xFF1A1C1E),
                surfaceVariant = Color(0xFFDFE2EB),
                onSurfaceVariant = Color(0xFF43474E),

                outline = Color(0xFF73777F),
                error = Color(0xFFBA1A1A),
                onError = Color.White
            )

        PinPothaAccent.TEAL ->
            lightColorScheme(
                primary = Color(0xFF006B5E),
                onPrimary = Color.White,
                primaryContainer = Color(0xFF9FF2DF),
                onPrimaryContainer = Color(0xFF00201B),

                secondary = Color(0xFF4A635D),
                onSecondary = Color.White,
                secondaryContainer = Color(0xFFCDE8E0),
                onSecondaryContainer = Color(0xFF06201B),

                tertiary = Color(0xFF446278),
                onTertiary = Color.White,
                tertiaryContainer = Color(0xFFCBE7FF),
                onTertiaryContainer = Color(0xFF001E2E),

                background = Color(0xFFF7FBF9),
                onBackground = Color(0xFF191C1B),

                surface = Color(0xFFF7FBF9),
                onSurface = Color(0xFF191C1B),
                surfaceVariant = Color(0xFFDAE5E1),
                onSurfaceVariant = Color(0xFF3F4946),

                outline = Color(0xFF6F7976),
                error = Color(0xFFBA1A1A),
                onError = Color.White
            )

        PinPothaAccent.ROSE ->
            lightColorScheme(
                primary = Color(0xFFA33B63),
                onPrimary = Color.White,
                primaryContainer = Color(0xFFFFD9E2),
                onPrimaryContainer = Color(0xFF3E001D),

                secondary = Color(0xFF74565F),
                onSecondary = Color.White,
                secondaryContainer = Color(0xFFFFD9E2),
                onSecondaryContainer = Color(0xFF2B151C),

                tertiary = Color(0xFF7C5635),
                onTertiary = Color.White,
                tertiaryContainer = Color(0xFFFFDCC0),
                onTertiaryContainer = Color(0xFF2D1600),

                background = Color(0xFFFFF8F8),
                onBackground = Color(0xFF211A1C),

                surface = Color(0xFFFFF8F8),
                onSurface = Color(0xFF211A1C),
                surfaceVariant = Color(0xFFF3DDE2),
                onSurfaceVariant = Color(0xFF514347),

                outline = Color(0xFF837377),
                error = Color(0xFFBA1A1A),
                onError = Color.White
            )

        PinPothaAccent.ORANGE ->
            lightColorScheme(
                primary = Color(0xFF8B5000),
                onPrimary = Color.White,
                primaryContainer = Color(0xFFFFDCBE),
                onPrimaryContainer = Color(0xFF2C1600),

                secondary = Color(0xFF715A41),
                onSecondary = Color.White,
                secondaryContainer = Color(0xFFFDDDBD),
                onSecondaryContainer = Color(0xFF281805),

                tertiary = Color(0xFF58633A),
                onTertiary = Color.White,
                tertiaryContainer = Color(0xFFDCE8B5),
                onTertiaryContainer = Color(0xFF161E00),

                background = Color(0xFFFFF8F4),
                onBackground = Color(0xFF211A15),

                surface = Color(0xFFFFF8F4),
                onSurface = Color(0xFF211A15),
                surfaceVariant = Color(0xFFF1E0D3),
                onSurfaceVariant = Color(0xFF50453C),

                outline = Color(0xFF827568),
                error = Color(0xFFBA1A1A),
                onError = Color.White
            )
    }


private fun darkScheme(
    accent: PinPothaAccent
): ColorScheme =
    when (accent) {

        PinPothaAccent.PURPLE ->
            darkColorScheme(
                primary = Color(0xFFD0BCFF),
                onPrimary = Color(0xFF381E72),
                primaryContainer = Color(0xFF4F378B),
                onPrimaryContainer = Color(0xFFEADDFF),

                secondary = Color(0xFFCCC2DC),
                onSecondary = Color(0xFF332D41),
                secondaryContainer = Color(0xFF4A4458),
                onSecondaryContainer = Color(0xFFE8DEF8),

                tertiary = Color(0xFFEFB8C8),
                onTertiary = Color(0xFF492532),
                tertiaryContainer = Color(0xFF633B48),
                onTertiaryContainer = Color(0xFFFFD8E4),

                background = Color(0xFF1C1B1F),
                onBackground = Color(0xFFE6E1E5),

                surface = Color(0xFF1C1B1F),
                onSurface = Color(0xFFE6E1E5),
                surfaceVariant = Color(0xFF49454F),
                onSurfaceVariant = Color(0xFFCAC4D0),

                outline = Color(0xFF938F99),
                error = Color(0xFFF2B8B5),
                onError = Color(0xFF601410)
            )

        PinPothaAccent.BLUE ->
            darkColorScheme(
                primary = Color(0xFF9ECAFF),
                onPrimary = Color(0xFF003258),
                primaryContainer = Color(0xFF00497D),
                onPrimaryContainer = Color(0xFFD1E4FF),

                secondary = Color(0xFFBBC7DB),
                onSecondary = Color(0xFF253140),
                secondaryContainer = Color(0xFF3B4858),
                onSecondaryContainer = Color(0xFFD7E3F7),

                tertiary = Color(0xFFD6BEE4),
                onTertiary = Color(0xFF3B2948),
                tertiaryContainer = Color(0xFF523F5F),
                onTertiaryContainer = Color(0xFFF2DAFF),

                background = Color(0xFF1A1C1E),
                onBackground = Color(0xFFE2E2E6),

                surface = Color(0xFF1A1C1E),
                onSurface = Color(0xFFE2E2E6),
                surfaceVariant = Color(0xFF43474E),
                onSurfaceVariant = Color(0xFFC3C7CF),

                outline = Color(0xFF8D9199),
                error = Color(0xFFFFB4AB),
                onError = Color(0xFF690005)
            )

        PinPothaAccent.TEAL ->
            darkColorScheme(
                primary = Color(0xFF82D5C3),
                onPrimary = Color(0xFF00382F),
                primaryContainer = Color(0xFF005046),
                onPrimaryContainer = Color(0xFF9FF2DF),

                secondary = Color(0xFFB1CCC4),
                onSecondary = Color(0xFF1C352F),
                secondaryContainer = Color(0xFF334B45),
                onSecondaryContainer = Color(0xFFCDE8E0),

                tertiary = Color(0xFFACCCE4),
                onTertiary = Color(0xFF123348),
                tertiaryContainer = Color(0xFF2C4A60),
                onTertiaryContainer = Color(0xFFCBE7FF),

                background = Color(0xFF101413),
                onBackground = Color(0xFFE0E3E1),

                surface = Color(0xFF101413),
                onSurface = Color(0xFFE0E3E1),
                surfaceVariant = Color(0xFF3F4946),
                onSurfaceVariant = Color(0xFFBEC9C5),

                outline = Color(0xFF89938F),
                error = Color(0xFFFFB4AB),
                onError = Color(0xFF690005)
            )

        PinPothaAccent.ROSE ->
            darkColorScheme(
                primary = Color(0xFFFFB0C8),
                onPrimary = Color(0xFF610032),
                primaryContainer = Color(0xFF842249),
                onPrimaryContainer = Color(0xFFFFD9E2),

                secondary = Color(0xFFE3BDC6),
                onSecondary = Color(0xFF422931),
                secondaryContainer = Color(0xFF5A3F47),
                onSecondaryContainer = Color(0xFFFFD9E2),

                tertiary = Color(0xFFEFBD94),
                onTertiary = Color(0xFF48290C),
                tertiaryContainer = Color(0xFF623F20),
                onTertiaryContainer = Color(0xFFFFDCC0),

                background = Color(0xFF191113),
                onBackground = Color(0xFFEFE0E2),

                surface = Color(0xFF191113),
                onSurface = Color(0xFFEFE0E2),
                surfaceVariant = Color(0xFF514347),
                onSurfaceVariant = Color(0xFFD6C2C6),

                outline = Color(0xFF9F8C91),
                error = Color(0xFFFFB4AB),
                onError = Color(0xFF690005)
            )

        PinPothaAccent.ORANGE ->
            darkColorScheme(
                primary = Color(0xFFFFB870),
                onPrimary = Color(0xFF4A2800),
                primaryContainer = Color(0xFF693C00),
                onPrimaryContainer = Color(0xFFFFDCBE),

                secondary = Color(0xFFE0C2A2),
                onSecondary = Color(0xFF3F2D17),
                secondaryContainer = Color(0xFF57432B),
                onSecondaryContainer = Color(0xFFFDDDBD),

                tertiary = Color(0xFFC0CC9B),
                onTertiary = Color(0xFF2B3411),
                tertiaryContainer = Color(0xFF414B25),
                onTertiaryContainer = Color(0xFFDCE8B5),

                background = Color(0xFF18120E),
                onBackground = Color(0xFFECE1D9),

                surface = Color(0xFF18120E),
                onSurface = Color(0xFFECE1D9),
                surfaceVariant = Color(0xFF50453C),
                onSurfaceVariant = Color(0xFFD4C4B8),

                outline = Color(0xFF9C8F84),
                error = Color(0xFFFFB4AB),
                onError = Color(0xFF690005)
            )
    }


@Composable
fun PinPothaTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    accent: PinPothaAccent = PinPothaAccent.PURPLE,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme =
            if (darkTheme) {
                darkScheme(accent)
            } else {
                lightScheme(accent)
            },
        content = content
    )
}
